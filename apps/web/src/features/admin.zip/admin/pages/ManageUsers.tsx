// apps/web/src/features/admin/pages/ManageUsers.tsx
import { useState, useEffect, useMemo } from "react";
import { useSearchParams } from "react-router-dom";
import { getUsers, updateUserRole, updateUserStatus, deleteUser } from "@/features/admin/api/admin.api";
import type { User } from "@/types/user";
import { FaTrash, FaBan, FaSearch } from "react-icons/fa";
import toast from "react-hot-toast";

const toDateSafe = (value: any): Date | null => {
  if (value == null) return null;
  if (value instanceof Date) return isNaN(value.getTime()) ? null : value;
  if (typeof value === "string" || typeof value === "number") {
    const d = new Date(value);
    return isNaN(d.getTime()) ? null : d;
  }
  if (typeof value === "object" && typeof value.seconds === "number") {
    const d = new Date(value.seconds * 1000);
    return isNaN(d.getTime()) ? null : d;
  }
  return null;
};

const formatDate = (value: any) => {
  const d = toDateSafe(value);
  return d ? d.toLocaleDateString() : "-";
};

const displayUserName = (u: User) => {
  const anyU = u as any;
  return anyU.nickname || u.displayName || "Unknown";
};

const normalizeRole = (u: any) => {
  const roles = u?.roles || {};
  if (roles?.superAdmin) return "superAdmin";
  if (roles?.admin || u?.isAdmin || u?.role === "admin") return "admin";
  return String(u?.role || "user");
};

const normalizeStatus = (u: any) => {
  return String(u?.status || "active");
};

const ManageUsers = () => {
  const [sp, setSp] = useSearchParams();
  const focusId = (sp.get("focus") || "").trim();

  const [users, setUsers] = useState<User[]>([]);
  const [isLoading, setIsLoading] = useState(true);

  const [q, setQ] = useState((sp.get("q") || "").trim());
  const [roleFilter, setRoleFilter] = useState((sp.get("role") || "all").trim());
  const [statusFilter, setStatusFilter] = useState((sp.get("status") || "all").trim());

  const [isBanModalOpen, setIsBanModalOpen] = useState(false);
  const [selectedUserId, setSelectedUserId] = useState<string | null>(null);
  const [banReason, setBanReason] = useState("");

  const loadUsers = async () => {
    try {
      setIsLoading(true);
      const data = await getUsers();
      setUsers(Array.isArray(data) ? data : []);
    } catch (err) {
      console.error(err);
      toast.error("유저 목록을 불러오지 못했습니다.");
    } finally {
      setIsLoading(false);
    }
  };

  useEffect(() => {
    loadUsers();
  }, []);

  // URL → state
  useEffect(() => {
    setQ((sp.get("q") || "").trim());
    setRoleFilter((sp.get("role") || "all").trim());
    setStatusFilter((sp.get("status") || "all").trim());
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sp.toString()]);

  // state → URL (공유/바로가기)
  useEffect(() => {
    setSp((prev) => {
      const p = new URLSearchParams(prev);

      const qq = q.trim();
      if (qq) p.set("q", qq);
      else p.delete("q");

      if (roleFilter && roleFilter !== "all") p.set("role", roleFilter);
      else p.delete("role");

      if (statusFilter && statusFilter !== "all") p.set("status", statusFilter);
      else p.delete("status");

      if (!focusId) p.delete("focus");
      return p;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [q, roleFilter, statusFilter]);

  const filteredUsers = useMemo(() => {
    const qq = q.trim().toLowerCase();

    return users
      .map((u) => {
        const anyU = u as any;
        return {
          ...u,
          _role: normalizeRole(anyU),
          _status: normalizeStatus(anyU),
        } as any;
      })
      .filter((u: any) => {
        if (!qq) return true;
        const hay = `${displayUserName(u)} ${u.email || ""} ${u._role} ${u._status}`.toLowerCase();
        return hay.includes(qq);
      })
      .filter((u: any) => {
        if (!roleFilter || roleFilter === "all") return true;
        return String(u._role).toLowerCase() === roleFilter.toLowerCase();
      })
      .filter((u: any) => {
        if (!statusFilter || statusFilter === "all") return true;
        return String(u._status).toLowerCase() === statusFilter.toLowerCase();
      });
  }, [users, q, roleFilter, statusFilter]);

  // focus scroll
  useEffect(() => {
    if (!focusId) return;
    if (!filteredUsers.length) return;

    const el = document.getElementById(`user-row-${focusId}`);
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [focusId, filteredUsers]);

  const handleRoleChange = async (userId: string, newRole: "admin" | "user") => {
    try {
      await updateUserRole(userId, newRole);
      setUsers((prev) => prev.map((u) => (u.id === userId ? ({ ...u, role: newRole } as any) : u)));
      toast.success("권한이 변경되었습니다.");
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || "권한 변경 실패 (superAdmin만 가능할 수 있음)");
    }
  };

  const requestStatusChange = (userId: string, newStatus: string) => {
    if (newStatus === "banned") {
      setSelectedUserId(userId);
      setBanReason("");
      setIsBanModalOpen(true);
    } else {
      handleStatusChange(userId, "active");
    }
  };

  const handleStatusChange = async (userId: string, newStatus: "active" | "banned", memo?: string) => {
    try {
      await updateUserStatus(userId, newStatus, memo);
      setUsers((prev) => prev.map((u) => (u.id === userId ? ({ ...u, status: newStatus } as any) : u)));
      toast.success(newStatus === "banned" ? "유저가 차단되었습니다." : "유저가 활성화되었습니다.");
      setIsBanModalOpen(false);
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || "상태 변경 실패");
    }
  };

  const confirmBan = () => {
    if (!selectedUserId) return;
    if (!banReason.trim()) {
      toast.error("차단 사유를 입력해주세요.");
      return;
    }
    handleStatusChange(selectedUserId, "banned", banReason);
  };

  const handleDeleteUser = async (userId: string) => {
    const ok = window.prompt(`정말 삭제(계정 제거)하시겠습니까?\n\n삭제하려면 DELETE 를 입력하세요.`);
    if (ok !== "DELETE") return;

    try {
      await deleteUser(userId);
      setUsers((prev) => prev.filter((u) => u.id !== userId));
      toast.success("유저가 삭제되었습니다.");
    } catch (e: any) {
      console.error(e);
      toast.error(e?.message || "삭제 실패 (superAdmin만 가능할 수 있음)");
    }
  };

  if (isLoading) return <div className="p-8 text-center text-gray-500">로딩 중...</div>;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-4">
      <div className="flex items-end justify-between gap-3 flex-wrap">
        <div>
          <h1 className="text-2xl font-bold text-gray-800">회원 관리</h1>
          {focusId ? (
            <p className="text-xs text-gray-500 mt-1">
              포커스: <span className="font-mono">{focusId}</span>
            </p>
          ) : null}
        </div>

        <div className="flex items-center gap-2">
          <div className="relative">
            <FaSearch className="absolute left-3 top-2.5 text-gray-400" />
            <input
              value={q}
              onChange={(e) => setQ(e.target.value)}
              placeholder="검색 (q=)"
              className="w-72 pl-9 pr-3 py-2 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-400 text-sm"
            />
          </div>

          <select
            value={roleFilter}
            onChange={(e) => setRoleFilter(e.target.value)}
            className="px-3 py-2 rounded-lg border border-gray-300 outline-none text-sm"
          >
            <option value="all">권한: 전체</option>
            <option value="superAdmin">superAdmin</option>
            <option value="admin">admin</option>
            <option value="user">user</option>
          </select>

          <select
            value={statusFilter}
            onChange={(e) => setStatusFilter(e.target.value)}
            className="px-3 py-2 rounded-lg border border-gray-300 outline-none text-sm"
          >
            <option value="all">상태: 전체</option>
            <option value="active">active</option>
            <option value="banned">banned</option>
          </select>

          <button onClick={loadUsers} className="px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-sm font-bold">
            새로고침
          </button>
        </div>
      </div>

      <div className="bg-white rounded-xl shadow-sm border border-gray-200 overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full text-left border-collapse">
            <thead className="bg-gray-50 text-gray-600 text-sm uppercase">
              <tr>
                <th className="px-6 py-4 font-semibold">닉네임 / 이메일</th>
                <th className="px-6 py-4 font-semibold">가입일</th>
                <th className="px-6 py-4 font-semibold">권한</th>
                <th className="px-6 py-4 font-semibold">상태</th>
                <th className="px-6 py-4 font-semibold text-center">관리</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-gray-100">
              {filteredUsers.map((user: any) => {
                const isFocus = focusId && user.id === focusId;
                return (
                  <tr
                    key={user.id}
                    id={`user-row-${user.id}`}
                    className={`hover:bg-gray-50 transition ${isFocus ? "bg-yellow-50 ring-2 ring-yellow-200" : ""}`}
                  >
                    <td className="px-6 py-4">
                      <div className="font-medium text-gray-900">{displayUserName(user)}</div>
                      <div className="text-sm text-gray-500">{user.email || "-"}</div>
                    </td>

                    <td className="px-6 py-4 text-sm text-gray-500">{formatDate(user.createdAt)}</td>

                    <td className="px-6 py-4">
                      <select
                        value={(user.role as any) || "user"}
                        onChange={(e) => handleRoleChange(user.id, e.target.value as "admin" | "user")}
                        className="bg-gray-100 text-gray-700 text-sm rounded px-2 py-1 outline-none"
                      >
                        <option value="user">User</option>
                        <option value="admin">Admin</option>
                      </select>
                    </td>

                    <td className="px-6 py-4">
                      <select
                        value={(user.status as any) || "active"}
                        onChange={(e) => requestStatusChange(user.id, e.target.value)}
                        className={`px-2 py-1 rounded text-sm font-bold outline-none cursor-pointer
                          ${(user.status as any) === "banned" ? "bg-red-100 text-red-700" : "bg-green-100 text-green-700"}
                        `}
                      >
                        <option value="active">Active</option>
                        <option value="banned">Banned</option>
                      </select>
                    </td>

                    <td className="px-6 py-4 text-center">
                      <button onClick={() => handleDeleteUser(user.id)} className="text-gray-400 hover:text-red-600 p-2">
                        <FaTrash />
                      </button>
                    </td>
                  </tr>
                );
              })}

              {filteredUsers.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-6 py-12 text-center text-gray-500">
                    조건에 맞는 회원이 없습니다.
                  </td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>

      {isBanModalOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/50 backdrop-blur-sm animate-fade-in">
          <div className="bg-white rounded-lg shadow-xl w-full max-w-md p-6">
            <h3 className="text-lg font-bold text-gray-800 mb-2 flex items-center gap-2">
              <FaBan className="text-red-500" /> 유저 차단
            </h3>
            <p className="text-sm text-gray-600 mb-4">차단 사유를 입력해주세요.</p>

            <textarea
              className="w-full h-32 p-3 border border-gray-300 rounded focus:ring-2 focus:ring-red-500 outline-none text-sm resize-none"
              placeholder="예: 지속적인 욕설"
              value={banReason}
              onChange={(e) => setBanReason(e.target.value)}
            />

            <div className="flex justify-end gap-2 mt-4">
              <button
                onClick={() => setIsBanModalOpen(false)}
                className="px-4 py-2 rounded text-gray-600 hover:bg-gray-100 text-sm"
              >
                취소
              </button>
              <button onClick={confirmBan} className="px-4 py-2 rounded bg-red-600 text-white hover:bg-red-700 text-sm">
                차단 확정
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default ManageUsers;
