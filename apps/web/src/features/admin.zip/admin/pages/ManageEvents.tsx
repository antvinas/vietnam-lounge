import { useEffect, useMemo, useRef, useState } from "react";
import { Link, useSearchParams } from "react-router-dom";
import toast from "react-hot-toast";
import { FaPlus, FaSearch, FaRegClock, FaRegCheckCircle, FaRegTimesCircle, FaSlidersH } from "react-icons/fa";

import {
  addEvent,
  deleteEvent,
  getEvents,
  updateEvent,
  type AdminEventData,
} from "@/features/admin/api/admin.api";
import { formatRange, parseYmdLocal, toDateMaybe } from "@/features/admin/utils/datetime";

import Pagination from "@/components/common/Pagination";
import DensityToggle from "@/components/common/DensityToggle";
import EmptyState from "@/components/common/EmptyState";
import Modal from "@/components/common/Modal";

import EventRowActions from "@/features/admin/components/events/EventRowActions";
import EventAdvancedFilters, { type VisibilityFilter } from "@/features/admin/components/events/EventAdvancedFilters";
import EventSavedViews from "@/features/admin/components/events/EventSavedViews";
import EventPreviewPanel from "@/features/admin/components/events/EventPreviewPanel";

import EventBulkActionsBar, { type BulkStatus } from "@/features/admin/components/events/EventBulkActionsBar";
import { useRowSelection } from "@/features/admin/hooks/useRowSelection";

type ModeFilter = "all" | "explorer" | "nightlife";
type StatusFilter = "all" | "upcoming" | "active" | "past";
type SortKey = "date_desc" | "date_asc" | "updated_desc" | "title_asc";

function getStatus(e: AdminEventData): "upcoming" | "active" | "past" {
  // ✅ (선택) status 필드가 있으면 그걸 우선 사용(벌크 “상태 변경” 지원)
  const explicit = String((e as any)?.status || "").trim();
  if (explicit === "upcoming" || explicit === "active" || explicit === "past") return explicit;

  const start = parseYmdLocal(e.date);
  const end = parseYmdLocal(e.endDate || e.date);
  if (!start) return "upcoming";

  const today = new Date();
  const t0 = new Date(today.getFullYear(), today.getMonth(), today.getDate()); // local midnight

  const s = new Date(start.getFullYear(), start.getMonth(), start.getDate());
  const e0 = end ? new Date(end.getFullYear(), end.getMonth(), end.getDate()) : s;

  if (t0.getTime() < s.getTime()) return "upcoming";
  if (t0.getTime() > e0.getTime()) return "past";
  return "active";
}

function clampInt(n: any, min: number, max: number, fallback: number) {
  const v = Number.isFinite(Number(n)) ? Number(n) : fallback;
  return Math.min(max, Math.max(min, Math.trunc(v)));
}

function normalizeSort(v: any): SortKey {
  const s = String(v || "").trim();
  if (s === "date_asc" || s === "date_desc" || s === "updated_desc" || s === "title_asc") return s;
  return "date_desc";
}

function normalizeMode(v: any): ModeFilter {
  const s = String(v || "").trim();
  if (s === "explorer" || s === "nightlife" || s === "all") return s;
  return "all";
}

function normalizeStatus(v: any): StatusFilter {
  const s = String(v || "").trim();
  if (s === "upcoming" || s === "active" || s === "past" || s === "all") return s;
  return "all";
}

function normalizeYmd(v: any): string {
  const s = String(v ?? "").trim();
  return /^\d{4}-\d{2}-\d{2}$/.test(s) ? s : "";
}

function normalizeCity(v: any): string {
  return String(v ?? "").trim();
}

function normalizeVisibility(v: any): VisibilityFilter {
  const s = String(v ?? "").trim();
  if (s === "public" || s === "private" || s === "all") return s;
  return "all";
}

function getUpdatedAtMs(e: any): number {
  const u = toDateMaybe(e?.updatedAt);
  if (u) return u.getTime();
  const c = toDateMaybe(e?.createdAt);
  if (c) return c.getTime();
  return 0;
}

function statusText(s: StatusFilter) {
  if (s === "upcoming") return "예정";
  if (s === "active") return "오늘";
  if (s === "past") return "종료";
  return "전체";
}

function intersectsDateRange(eventStartYmd: string, eventEndYmd: string, rangeStartYmd: string, rangeEndYmd: string) {
  const es = parseYmdLocal(eventStartYmd);
  const ee = parseYmdLocal(eventEndYmd || eventStartYmd);
  if (!es) return true;

  const evS = es.getTime();
  const evE = (ee ?? es).getTime();

  const rs = rangeStartYmd ? parseYmdLocal(rangeStartYmd)?.getTime() : undefined;
  const re = rangeEndYmd ? parseYmdLocal(rangeEndYmd)?.getTime() : undefined;

  if (rs == null && re == null) return true;
  if (rs != null && re == null) return evE >= rs;
  if (rs == null && re != null) return evS <= re;

  return evS <= (re as number) && evE >= (rs as number);
}

function getVisibilityFlag(e: AdminEventData): boolean | undefined {
  const v = (e as any)?.isPublic;
  if (typeof v === "boolean") return v;

  const vv = (e as any)?.visibility;
  if (vv === "public") return true;
  if (vv === "private") return false;

  return undefined;
}

export default function ManageEvents() {
  const [sp, setSp] = useSearchParams();
  const focusId = (sp.get("focus") || "").trim();

  const [events, setEvents] = useState<AdminEventData[]>([]);
  const [loading, setLoading] = useState(true);

  const [mode, setMode] = useState<ModeFilter>(() => normalizeMode(sp.get("mode")));
  const [status, setStatus] = useState<StatusFilter>(() => normalizeStatus(sp.get("status")));
  const [q, setQ] = useState((sp.get("q") || "").trim());
  const [sort, setSort] = useState<SortKey>(() => normalizeSort(sp.get("sort")));
  const [page, setPage] = useState(() => clampInt(sp.get("page"), 1, 9999, 1));
  const [limit, setLimit] = useState(() => clampInt(sp.get("limit"), 20, 200, 20));

  const [rangeStart, setRangeStart] = useState(() => normalizeYmd(sp.get("rangeStart")));
  const [rangeEnd, setRangeEnd] = useState(() => normalizeYmd(sp.get("rangeEnd")));
  const [city, setCity] = useState(() => normalizeCity(sp.get("city")));
  const [visibility, setVisibility] = useState<VisibilityFilter>(() => normalizeVisibility(sp.get("visibility")));

  const [advancedOpen, setAdvancedOpen] = useState(false);

  // ✅ Preview 상태 + ✅ Active(선택) 유지
  const [previewOpen, setPreviewOpen] = useState(false);
  const [previewEvent, setPreviewEvent] = useState<AdminEventData | null>(null);
  const [activeId, setActiveId] = useState<string>(""); // 패널 닫아도 선택 강조 유지
  const lastOpenedRowIdRef = useRef<string>("");

  const openPreview = (e: AdminEventData) => {
    const id = String((e as any)?.id || "");
    setActiveId(id);
    lastOpenedRowIdRef.current = id;
    setPreviewEvent(e);
    setPreviewOpen(true);
  };

  const closePreview = () => {
    setPreviewOpen(false);
    const id = lastOpenedRowIdRef.current;
    if (id) {
      window.setTimeout(() => {
        const el = document.getElementById(`event-row-${id}`);
        (el as any)?.focus?.();
      }, 0);
    }
  };

  const getEditTo = (e?: AdminEventData | null) => {
    if (!e?.id) return "";
    return `/admin/events/${e.id}/edit?mode=${encodeURIComponent(e.mode || "explorer")}`;
  };

  const tableAnchorRef = useRef<HTMLDivElement | null>(null);
  const scrollToTable = () => {
    const el = tableAnchorRef.current;
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "start" });
  };

  const [pulseStatus, setPulseStatus] = useState<StatusFilter | null>(null);
  const pulseTimerRef = useRef<number | null>(null);
  const statusBtnRefs = useRef<Partial<Record<StatusFilter, HTMLButtonElement | null>>>({});

  const triggerPulse = (v: StatusFilter) => {
    setPulseStatus(v);
    if (pulseTimerRef.current) window.clearTimeout(pulseTimerRef.current);
    pulseTimerRef.current = window.setTimeout(() => setPulseStatus(null), 900);
  };

  useEffect(() => {
    return () => {
      if (pulseTimerRef.current) window.clearTimeout(pulseTimerRef.current);
    };
  }, []);

  const resetFilters = () => {
    setMode("all");
    setStatus("all");
    setQ("");
    setPage(1);

    setRangeStart("");
    setRangeEnd("");
    setCity("");
    setVisibility("all");

    triggerPulse("all");
    requestAnimationFrame(() => {
      scrollToTable();
      window.setTimeout(() => {
        statusBtnRefs.current["all"]?.focus?.();
      }, 200);
    });
  };

  const resetAdvancedOnly = () => {
    setRangeStart("");
    setRangeEnd("");
    setCity("");
    setVisibility("all");
  };

  const load = async () => {
    try {
      setLoading(true);
      const data = await getEvents();
      setEvents(Array.isArray(data) ? data : []);
    } catch {
      toast.error("이벤트를 불러오지 못했습니다.");
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    load();
  }, []);

  // URL → state 동기화
  useEffect(() => {
    const nextMode = normalizeMode(sp.get("mode"));
    const nextStatus = normalizeStatus(sp.get("status"));
    const nextQ = (sp.get("q") || "").trim();
    const nextSort = normalizeSort(sp.get("sort"));
    const nextPage = clampInt(sp.get("page"), 1, 9999, 1);
    const nextLimit = clampInt(sp.get("limit"), 20, 200, 20);

    const nextRangeStart = normalizeYmd(sp.get("rangeStart"));
    const nextRangeEnd = normalizeYmd(sp.get("rangeEnd"));
    const nextCity = normalizeCity(sp.get("city"));
    const nextVisibility = normalizeVisibility(sp.get("visibility"));

    setMode(nextMode);
    setStatus(nextStatus);
    setQ(nextQ);
    setSort(nextSort);
    setPage(nextPage);
    setLimit(nextLimit);

    setRangeStart(nextRangeStart);
    setRangeEnd(nextRangeEnd);
    setCity(nextCity);
    setVisibility(nextVisibility);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [sp.toString()]);

  // state → URL 동기화
  useEffect(() => {
    setSp((prev) => {
      const p = new URLSearchParams(prev);

      if (mode !== "all") p.set("mode", mode);
      else p.delete("mode");

      if (status !== "all") p.set("status", status);
      else p.delete("status");

      const qq = q.trim();
      if (qq) p.set("q", qq);
      else p.delete("q");

      if (sort !== "date_desc") p.set("sort", sort);
      else p.delete("sort");

      if (page !== 1) p.set("page", String(page));
      else p.delete("page");

      if (limit !== 20) p.set("limit", String(limit));
      else p.delete("limit");

      if (rangeStart) p.set("rangeStart", rangeStart);
      else p.delete("rangeStart");

      if (rangeEnd) p.set("rangeEnd", rangeEnd);
      else p.delete("rangeEnd");

      if (city) p.set("city", city);
      else p.delete("city");

      if (visibility !== "all") p.set("visibility", visibility);
      else p.delete("visibility");

      if (!focusId) p.delete("focus");

      return p;
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, status, q, sort, page, limit, rangeStart, rangeEnd, city, visibility]);

  useEffect(() => {
    setPage(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [mode, status, q, sort, limit, rangeStart, rangeEnd, city, visibility]);

  const cityOptions = useMemo(() => {
    const set = new Set<string>();
    events.forEach((e) => {
      const c = String((e as any).city ?? "").trim();
      if (c) set.add(c);
    });
    return Array.from(set).sort((a, b) => a.localeCompare(b, "ko"));
  }, [events]);

  const filteredAll = useMemo(() => {
    const qq = q.trim().toLowerCase();
    const cityKey = city.trim().toLowerCase();

    const list = events
      .filter((e) => (mode === "all" ? true : (e as any).mode === mode))
      .filter((e) => (status === "all" ? true : getStatus(e) === status))
      .filter((e) => {
        const start = (e as any).date;
        const end = (e as any).endDate || (e as any).date;
        return intersectsDateRange(start, end, rangeStart, rangeEnd);
      })
      .filter((e) => {
        if (!cityKey) return true;
        return String((e as any).city ?? "").trim().toLowerCase() === cityKey;
      })
      .filter((e) => {
        if (visibility === "all") return true;
        const flag = getVisibilityFlag(e);
        if (flag == null) return false;
        return visibility === "public" ? flag === true : flag === false;
      })
      .filter((e) => {
        if (!qq) return true;
        return (
          String((e as any).title || "").toLowerCase().includes(qq) ||
          String((e as any).location || "").toLowerCase().includes(qq) ||
          String((e as any).city || "").toLowerCase().includes(qq) ||
          String((e as any).category || "").toLowerCase().includes(qq)
        );
      });

    const sorted = [...list].sort((a, b) => {
      if (sort === "title_asc") {
        return String((a as any).title || "").localeCompare(String((b as any).title || ""), "ko");
      }

      if (sort === "updated_desc") {
        const ua = getUpdatedAtMs(a as any);
        const ub = getUpdatedAtMs(b as any);
        if (ub !== ua) return ub - ua;

        const da = parseYmdLocal((a as any).date)?.getTime() ?? 0;
        const db = parseYmdLocal((b as any).date)?.getTime() ?? 0;
        return db - da;
      }

      const da = parseYmdLocal((a as any).date)?.getTime() ?? 0;
      const db = parseYmdLocal((b as any).date)?.getTime() ?? 0;

      if (sort === "date_asc") return da - db;
      return db - da;
    });

    return sorted;
  }, [events, mode, status, q, sort, rangeStart, rangeEnd, city, visibility]);

  const totalPages = useMemo(() => Math.max(1, Math.ceil(filteredAll.length / limit)), [filteredAll.length, limit]);

  useEffect(() => {
    if (page > totalPages) setPage(totalPages);
    if (page < 1) setPage(1);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [totalPages]);

  const paged = useMemo(() => {
    const start = (page - 1) * limit;
    return filteredAll.slice(start, start + limit);
  }, [filteredAll, page, limit]);

  // ✅ focus scroll
  useEffect(() => {
    if (!focusId) return;
    if (!paged.length) return;

    const el = document.getElementById(`event-row-${focusId}`);
    if (!el) return;
    el.scrollIntoView({ behavior: "smooth", block: "center" });
  }, [focusId, paged]);

  // ✅ 목록이 바뀌면 activeId 보정
  useEffect(() => {
    if (!paged.length) {
      setActiveId("");
      return;
    }
    if (!activeId) {
      setActiveId(String((paged[0] as any)?.id || ""));
      return;
    }
    const exists = paged.some((x) => String((x as any)?.id || "") === activeId);
    if (!exists) setActiveId(String((paged[0] as any)?.id || ""));
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [paged]);

  const summary = useMemo(() => {
    const all = events.length;
    const upcoming = events.filter((e) => getStatus(e) === "upcoming").length;
    const active = events.filter((e) => getStatus(e) === "active").length;
    const past = events.filter((e) => getStatus(e) === "past").length;
    return { all, upcoming, active, past };
  }, [events]);

  const appliedFilterCount = useMemo(() => {
    let c = 0;
    if (mode !== "all") c += 1;
    if (status !== "all") c += 1;
    if (q.trim()) c += 1;
    if (rangeStart || rangeEnd) c += 1;
    if (city.trim()) c += 1;
    if (visibility !== "all") c += 1;
    return c;
  }, [mode, status, q, rangeStart, rangeEnd, city, visibility]);

  const applied = useMemo(() => {
    const chips: string[] = [];
    if (mode !== "all") chips.push(mode === "nightlife" ? "Nightlife" : "Explorer");
    if (status !== "all") chips.push(status === "upcoming" ? "예정" : status === "active" ? "오늘" : "종료");
    if (q.trim()) chips.push(`검색: ${q.trim()}`);

    if (rangeStart || rangeEnd) {
      const a = rangeStart || "…";
      const b = rangeEnd || "…";
      chips.push(`기간: ${a} ~ ${b}`);
    }
    if (city.trim()) chips.push(`도시: ${city.trim()}`);
    if (visibility !== "all") chips.push(`공개: ${visibility === "public" ? "공개" : "비공개"}`);

    if (sort !== "date_desc") {
      chips.push(sort === "date_asc" ? "정렬: 시작일↑" : sort === "updated_desc" ? "정렬: 업데이트↓" : "정렬: 가나다");
    }
    if (limit !== 20) chips.push(`표시: ${limit}`);
    return chips;
  }, [mode, status, q, sort, limit, rangeStart, rangeEnd, city, visibility]);

  const statusBtn = (value: StatusFilter, label: string, icon: React.ReactNode) => {
    const active = status === value;
    const isPulse = pulseStatus === value;

    return (
      <button
        ref={(el) => {
          statusBtnRefs.current[value] = el;
        }}
        onClick={() => setStatus(value)}
        className={[
          "admin-chip admin-status-tab inline-flex items-center gap-2 rounded-lg text-sm font-bold border transition px-3 py-2",
          active ? "bg-slate-900 text-white border-slate-900" : "bg-white text-gray-700 border-gray-200 hover:bg-gray-50",
          isPulse ? "is-pulse" : "",
        ].join(" ")}
      >
        {icon} {label}
      </button>
    );
  };

  const statCard = (
    value: StatusFilter,
    label: string,
    count: number,
    tone: "slate" | "yellow" | "green" | "gray",
    icon: React.ReactNode
  ) => {
    const selected = status === value;

    const cls =
      `admin-stat admin-stat--${tone} ` +
      (selected ? "is-selected " : "") +
      (value === "active" ? "is-spotlight " : "");

    return (
      <button
        type="button"
        onClick={() => {
          setStatus(value);
          triggerPulse(value);
          requestAnimationFrame(() => scrollToTable());
        }}
        className={cls}
        aria-pressed={selected}
        aria-label={`${label} ${count}건`}
      >
        <div className="admin-stat-top">
          <span className={`admin-stat-icon admin-stat-icon--${tone}`}>{icon}</span>
          <span className="admin-stat-label">{label}</span>
          {selected ? <span className="admin-stat-selected">선택</span> : null}
        </div>

        <div className="admin-stat-bottom">
          <span className="admin-stat-num">{count}</span>
          <span className="admin-stat-unit">건</span>
        </div>

        <div className="admin-stat-cta" aria-hidden="true">
          바로 보기 <span className="admin-stat-cta-arrow">→</span>
        </div>
      </button>
    );
  };

  const stickyLabel = useMemo(() => {
    const s = statusText(status);
    const n = filteredAll.length;
    return { s, n };
  }, [status, filteredAll.length]);

  const showTodayEmptyHint = status === "active" && stickyLabel.n === 0;

  // =========================================================
  // 단건 삭제 Confirm + Undo
  // =========================================================
  const [deleteTarget, setDeleteTarget] = useState<AdminEventData | null>(null);
  const [deleteText, setDeleteText] = useState("");
  const [deleting, setDeleting] = useState(false);

  const closeDeleteModal = () => {
    setDeleteTarget(null);
    setDeleteText("");
    setDeleting(false);
  };

  const doUndo = async (deleted: AdminEventData) => {
    if (!deleted?.id) return;

    setEvents((prev) => {
      if (prev.some((x) => x.id === deleted.id)) return prev;
      return [...prev, deleted];
    });

    try {
      await updateEvent(deleted.id, { ...deleted });
      toast.success("복구되었습니다.");
    } catch {
      setEvents((prev) => prev.filter((x) => x.id !== deleted.id));
      toast.error("복구에 실패했습니다.");
    }
  };

  const confirmDelete = async () => {
    if (!deleteTarget?.id) return;

    if (deleteText.trim() !== "DELETE") {
      toast.error('삭제하려면 "DELETE" 를 입력하세요.');
      return;
    }

    const target = deleteTarget;
    setDeleting(true);

    try {
      await deleteEvent(target.id);
      setEvents((prev) => prev.filter((x) => x.id !== target.id));
      closeDeleteModal();

      toast.custom(
        (t) => (
          <div
            className={[
              "max-w-md w-full rounded-xl border border-gray-200 bg-white shadow-lg",
              "px-4 py-3 flex items-center justify-between gap-3",
            ].join(" ")}
          >
            <div className="min-w-0">
              <div className="text-sm font-extrabold text-gray-900">삭제 완료</div>
              <div className="text-xs text-gray-600 truncate">{(target as any).title}</div>
            </div>

            <div className="flex items-center gap-2 shrink-0">
              <button
                className="px-3 py-1.5 rounded-lg bg-gray-100 hover:bg-gray-200 text-xs font-bold"
                onClick={() => {
                  toast.dismiss(t.id);
                  void doUndo(target);
                }}
              >
                Undo
              </button>
              <button
                className="px-2 py-1.5 rounded-lg hover:bg-gray-100 text-xs font-bold text-gray-500"
                onClick={() => toast.dismiss(t.id)}
                aria-label="닫기"
              >
                ✕
              </button>
            </div>
          </div>
        ),
        { duration: 6000 }
      );
    } catch {
      setDeleting(false);
      toast.error("삭제에 실패했습니다.");
    }
  };

  const handleDuplicate = async (e: AdminEventData) => {
    try {
      const copy: AdminEventData = {
        ...(e as any),
        id: undefined as any,
        title: `${String((e as any).title || "").trim()} (복제)`,
      };

      const created = await addEvent(copy);
      const newId = (created as any)?.id;

      toast.success("복제되었습니다. 편집 화면으로 이동합니다.");
      if (newId) {
        window.location.href = `/admin/events/${newId}/edit?mode=${encodeURIComponent((copy as any).mode || "explorer")}`;
      } else {
        await load();
      }
    } catch {
      toast.error("복제에 실패했습니다.");
    }
  };

  const copyAdminEditLink = async (e: AdminEventData) => {
    if (!e?.id) return;
    const url = `${window.location.origin}/admin/events/${e.id}/edit?mode=${encodeURIComponent((e as any).mode || "explorer")}`;

    try {
      await navigator.clipboard.writeText(url);
      toast.success("링크를 복사했습니다.");
    } catch {
      const ta = document.createElement("textarea");
      ta.value = url;
      document.body.appendChild(ta);
      ta.select();
      try {
        document.execCommand("copy");
        toast.success("링크를 복사했습니다.");
      } catch {
        toast.error("링크 복사에 실패했습니다.");
      } finally {
        document.body.removeChild(ta);
      }
    }
  };

  // =========================================================
  // ✅ 키보드 네비게이션(↑/↓/Enter/Space/ESC)
  // =========================================================
  const tableKeyHandler = (ev: React.KeyboardEvent) => {
    if (!paged.length) return;

    const idx = paged.findIndex((x) => String((x as any)?.id || "") === activeId);
    const cur = idx >= 0 ? idx : 0;

    if (ev.key === "ArrowDown") {
      ev.preventDefault();
      const next = Math.min(paged.length - 1, cur + 1);
      const e = paged[next];
      const id = String((e as any)?.id || "");
      setActiveId(id);
      lastOpenedRowIdRef.current = id;
      if (previewOpen) setPreviewEvent(e);

      window.setTimeout(() => {
        const el = document.getElementById(`event-row-${id}`);
        el?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }, 0);
      return;
    }

    if (ev.key === "ArrowUp") {
      ev.preventDefault();
      const next = Math.max(0, cur - 1);
      const e = paged[next];
      const id = String((e as any)?.id || "");
      setActiveId(id);
      lastOpenedRowIdRef.current = id;
      if (previewOpen) setPreviewEvent(e);

      window.setTimeout(() => {
        const el = document.getElementById(`event-row-${id}`);
        el?.scrollIntoView({ behavior: "smooth", block: "nearest" });
      }, 0);
      return;
    }

    if (ev.key === "Enter" || ev.key === " ") {
      ev.preventDefault();
      const e = paged[cur];
      openPreview(e);
      return;
    }

    if (ev.key === "Escape") {
      if (previewOpen) {
        ev.preventDefault();
        closePreview();
      }
    }
  };

  // =========================================================
  // ✅ 벌크 선택/전체선택/액션
  // =========================================================
  const pagedIds = useMemo(() => paged.map((x) => String((x as any)?.id || "")).filter(Boolean), [paged]);

  // pruneOnVisibleChange=false: 페이지 이동해도 선택 유지(관리자툴에서 유용)
  const selection = useRowSelection(pagedIds, { pruneOnVisibleChange: false });

  const headerCbRef = useRef<HTMLInputElement | null>(null);
  const headerState = selection.getHeaderCheckboxState();
  useEffect(() => {
    if (!headerCbRef.current) return;
    headerCbRef.current.indeterminate = headerState.indeterminate;
  }, [headerState.indeterminate]);

  const selectionHint = useMemo(() => {
    if (selection.selectedCount <= 0) return "";
    const v = selection.visibleSelectedCount;
    const totalVisible = pagedIds.length;
    if (selection.selectedCount === v) return `현재 페이지 ${v}/${totalVisible} 선택됨`;
    return `현재 페이지 ${v}/${totalVisible} · 전체 ${selection.selectedCount} 선택됨`;
  }, [selection.selectedCount, selection.visibleSelectedCount, pagedIds.length]);

  const [bulkBusy, setBulkBusy] = useState(false);

  const summarize = (title: string, ok: number, fail: number) => {
    if (fail === 0) toast.success(`${title} 완료 (성공 ${ok})`);
    else toast.error(`${title} 완료 (성공 ${ok} / 실패 ${fail})`);
  };

  const bulkUpdateVisibility = async (isPublic: boolean) => {
    const ids = selection.selectedIds;
    if (!ids.length) return;

    setBulkBusy(true);

    // optimistic update + 실패시 복구
    const prevMap = new Map<string, any>();
    setEvents((prev) =>
      prev.map((e) => {
        const id = String((e as any)?.id || "");
        if (!ids.includes(id)) return e;

        prevMap.set(id, {
          isPublic: (e as any)?.isPublic,
          visibility: (e as any)?.visibility,
        });

        return {
          ...(e as any),
          isPublic,
          visibility: isPublic ? "public" : "private",
        } as any;
      })
    );

    const results = await Promise.allSettled(
      ids.map((id) => updateEvent(id, { isPublic, visibility: isPublic ? "public" : "private" } as any))
    );

    let ok = 0;
    let fail = 0;

    results.forEach((r, i) => {
      const id = ids[i];
      if (r.status === "fulfilled") ok += 1;
      else {
        fail += 1;
        // revert this one
        const snap = prevMap.get(id);
        setEvents((prev) =>
          prev.map((e) => {
            const eid = String((e as any)?.id || "");
            if (eid !== id) return e;
            return {
              ...(e as any),
              isPublic: snap?.isPublic,
              visibility: snap?.visibility,
            } as any;
          })
        );
      }
    });

    summarize(isPublic ? "공개 처리" : "비공개 처리", ok, fail);
    setBulkBusy(false);

    // 성공한 건들은 그대로 두고, 선택은 유지해도 되지만 보통은 해제하는 편이 실무에 안전
    selection.clear();
  };

  const bulkUpdateStatus = async (next: BulkStatus) => {
    const ids = selection.selectedIds;
    if (!ids.length) return;

    setBulkBusy(true);

    const prevMap = new Map<string, any>();
    setEvents((prev) =>
      prev.map((e) => {
        const id = String((e as any)?.id || "");
        if (!ids.includes(id)) return e;
        prevMap.set(id, { status: (e as any)?.status });
        return { ...(e as any), status: next } as any;
      })
    );

    const results = await Promise.allSettled(ids.map((id) => updateEvent(id, { status: next } as any)));

    let ok = 0;
    let fail = 0;

    results.forEach((r, i) => {
      const id = ids[i];
      if (r.status === "fulfilled") ok += 1;
      else {
        fail += 1;
        const snap = prevMap.get(id);
        setEvents((prev) =>
          prev.map((e) => {
            const eid = String((e as any)?.id || "");
            if (eid !== id) return e;
            return { ...(e as any), status: snap?.status } as any;
          })
        );
      }
    });

    summarize("상태 변경", ok, fail);
    setBulkBusy(false);
    selection.clear();
  };

  // 벌크 삭제(안전하게 모달 + DELETE 입력)
  const [bulkDeleteOpen, setBulkDeleteOpen] = useState(false);
  const [bulkDeleteText, setBulkDeleteText] = useState("");

  const openBulkDelete = () => {
    if (selection.selectedCount <= 0) return;
    setBulkDeleteText("");
    setBulkDeleteOpen(true);
  };

  const closeBulkDelete = () => {
    setBulkDeleteOpen(false);
    setBulkDeleteText("");
  };

  const confirmBulkDelete = async () => {
    const ids = selection.selectedIds;
    if (!ids.length) return;

    if (bulkDeleteText.trim() !== "DELETE") {
      toast.error('삭제하려면 "DELETE" 를 입력하세요.');
      return;
    }

    setBulkBusy(true);

    // optimistic: 일단 목록에서 제거 (실무 체감 빠름)
    const deletedSnapshots = new Map<string, AdminEventData>();
    setEvents((prev) => {
      prev.forEach((e) => {
        const id = String((e as any)?.id || "");
        if (ids.includes(id)) deletedSnapshots.set(id, e);
      });
      return prev.filter((e) => !ids.includes(String((e as any)?.id || "")));
    });

    const results = await Promise.allSettled(ids.map((id) => deleteEvent(id)));

    let ok = 0;
    let fail = 0;
    const failedIds: string[] = [];

    results.forEach((r, i) => {
      const id = ids[i];
      if (r.status === "fulfilled") ok += 1;
      else {
        fail += 1;
        failedIds.push(id);
      }
    });

    // 실패한 것 복구
    if (failedIds.length) {
      setEvents((prev) => {
        const addBack: AdminEventData[] = [];
        failedIds.forEach((id) => {
          const snap = deletedSnapshots.get(id);
          if (snap) addBack.push(snap);
        });
        return [...prev, ...addBack];
      });
    }

    closeBulkDelete();
    summarize("벌크 삭제", ok, fail);

    setBulkBusy(false);
    selection.clear();
  };

  const bulkDuplicate = async () => {
    const ids = selection.selectedIds;
    if (!ids.length) return;

    setBulkBusy(true);

    const selectedEvents = events.filter((e) => ids.includes(String((e as any)?.id || "")));

    const results = await Promise.allSettled(
      selectedEvents.map(async (e) => {
        const copy: AdminEventData = {
          ...(e as any),
          id: undefined as any,
          title: `${String((e as any).title || "").trim()} (복제)`,
        };
        return addEvent(copy);
      })
    );

    let ok = 0;
    let fail = 0;
    results.forEach((r) => {
      if (r.status === "fulfilled") ok += 1;
      else fail += 1;
    });

    // 새로 생성된 항목이 많으니 안전하게 reload
    await load();

    summarize("벌크 복제", ok, fail);
    setBulkBusy(false);
    selection.clear();
  };

  // =========================================================
  // render
  // =========================================================
  const visibleRowsHaveIds = pagedIds.length > 0;

  return (
    <div className="p-8 max-w-7xl mx-auto space-y-6">
      {/* ✅ 프리뷰 패널 */}
      <EventPreviewPanel
        open={previewOpen}
        event={previewEvent}
        editTo={getEditTo(previewEvent)}
        onClose={closePreview}
        onCopyLink={previewEvent ? () => void copyAdminEditLink(previewEvent) : undefined}
        onDuplicate={previewEvent ? () => void handleDuplicate(previewEvent) : undefined}
        onDelete={
          previewEvent
            ? () => {
                setDeleteTarget(previewEvent);
                setDeleteText("");
              }
            : undefined
        }
      />

      {/* ✅ 벌크 액션 바 */}
      <EventBulkActionsBar
        selectedCount={selection.selectedCount}
        hintText={selectionHint}
        disabled={bulkBusy}
        onClear={selection.clear}
        onSetVisibility={(isPublic) => void bulkUpdateVisibility(isPublic)}
        onSetStatus={(s) => void bulkUpdateStatus(s)}
        onDuplicate={() => void bulkDuplicate()}
        onDelete={openBulkDelete}
      />

      <div className="flex items-start justify-between gap-4 flex-wrap">
        <div className="min-w-[320px]">
          <h1 className="text-2xl font-bold text-gray-800">이벤트 관리</h1>

          <div className="admin-stats mt-4">
            {statCard("all", "전체", summary.all, "slate", <FaRegCheckCircle />)}
            {statCard("upcoming", "예정", summary.upcoming, "yellow", <FaRegClock />)}
            {statCard("active", "오늘", summary.active, "green", <FaRegCheckCircle />)}
            {statCard("past", "종료", summary.past, "gray", <FaRegTimesCircle />)}
          </div>

          <div className="mt-3 admin-result-line">
            결과 <span className="font-extrabold">{filteredAll.length}</span>건{" "}
            <span className="text-gray-400">(전체 {events.length}건)</span> ·{" "}
            {appliedFilterCount > 0 ? `필터 ${appliedFilterCount}개 적용됨` : "필터 없음"}
          </div>

          {applied.length ? (
            <div className="mt-2 flex gap-2 flex-wrap">
              {applied.map((c) => (
                <span key={c} className="admin-chip px-2 py-1 rounded bg-gray-100 text-gray-700 text-xs font-bold">
                  {c}
                </span>
              ))}
            </div>
          ) : null}

          {focusId ? (
            <div className="text-xs text-gray-500 mt-2">
              포커스: <span className="font-mono">{focusId}</span>
            </div>
          ) : null}
        </div>

        <div className="flex items-center gap-2">
          <DensityToggle />
          <Link
            to="/admin/events/new"
            className="admin-action-btn inline-flex items-center gap-2 bg-green-600 text-white font-bold px-4 py-2 rounded-lg hover:bg-green-700"
          >
            <FaPlus /> 이벤트 등록
          </Link>
        </div>
      </div>

      {/* Toolbar */}
      <div className="admin-toolbar bg-white rounded-xl border border-gray-200 shadow-sm p-4 flex flex-wrap gap-3 items-center">
        <div className="relative flex-1 min-w-[240px]">
          <FaSearch className="absolute left-3 top-3 text-gray-400" />
          <input
            className="w-full pl-10 pr-3 py-2 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-blue-500"
            placeholder="이벤트명/장소로 검색 (q=)"
            value={q}
            onChange={(e) => setQ(e.target.value)}
          />
        </div>

        <select
          className="px-3 py-2 rounded-lg border border-gray-300 outline-none"
          value={mode}
          onChange={(e) => setMode(e.target.value as ModeFilter)}
          aria-label="모드 필터"
        >
          <option value="all">전체</option>
          <option value="explorer">Explorer (Day)</option>
          <option value="nightlife">Nightlife (Night)</option>
        </select>

        <select
          className="px-3 py-2 rounded-lg border border-gray-300 outline-none"
          value={sort}
          onChange={(e) => setSort(e.target.value as SortKey)}
          aria-label="정렬"
        >
          <option value="date_desc">시작일(최신)</option>
          <option value="date_asc">시작일(오래된)</option>
          <option value="updated_desc">업데이트(최신)</option>
          <option value="title_asc">가나다</option>
        </select>

        <select
          className="px-3 py-2 rounded-lg border border-gray-300 outline-none"
          value={limit}
          onChange={(e) => setLimit(clampInt(e.target.value, 20, 200, 20))}
          aria-label="표시 개수"
        >
          <option value={20}>20</option>
          <option value={50}>50</option>
          <option value={100}>100</option>
        </select>

        <EventSavedViews compact />

        <button
          type="button"
          onClick={() => setAdvancedOpen((v) => !v)}
          className="admin-action-btn inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-sm font-extrabold"
          aria-expanded={advancedOpen}
        >
          <FaSlidersH /> 고급 필터
        </button>

        <button
          onClick={load}
          className="admin-action-btn px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-sm font-bold"
        >
          새로고침
        </button>
      </div>

      <EventAdvancedFilters
        open={advancedOpen}
        onToggle={() => setAdvancedOpen((v) => !v)}
        rangeStart={rangeStart}
        rangeEnd={rangeEnd}
        city={city}
        visibility={visibility}
        cityOptions={cityOptions}
        onChange={(patch) => {
          if (patch.rangeStart !== undefined) setRangeStart(patch.rangeStart);
          if (patch.rangeEnd !== undefined) setRangeEnd(patch.rangeEnd);
          if (patch.city !== undefined) setCity(patch.city);
          if (patch.visibility !== undefined) setVisibility(patch.visibility);
        }}
        onReset={resetAdvancedOnly}
      />

      <div className="flex gap-2 flex-wrap">
        {statusBtn("all", "전체", <FaRegCheckCircle className="opacity-70" />)}
        {statusBtn("upcoming", "예정", <FaRegClock className="opacity-70" />)}
        {statusBtn("active", "오늘", <FaRegCheckCircle className="opacity-70" />)}
        {statusBtn("past", "종료", <FaRegTimesCircle className="opacity-70" />)}
      </div>

      <div ref={tableAnchorRef} />

      <div
        className="bg-white rounded-xl border border-gray-200 shadow-sm overflow-hidden"
        tabIndex={0}
        role="region"
        aria-label="이벤트 테이블"
        onKeyDown={tableKeyHandler}
      >
        <div className="admin-sticky-bar">
          <div className="admin-sticky-pill" role="status" aria-live="polite">
            현재: <span className="admin-sticky-strong">{stickyLabel.s}</span> ·{" "}
            <span className="admin-sticky-strong">{stickyLabel.n}</span>건
            <span className="admin-sticky-muted">
              {mode !== "all" ? ` · ${mode === "nightlife" ? "Nightlife" : "Explorer"}` : ""}
              {q.trim() ? ` · 검색` : ""}
              {city.trim() ? ` · ${city.trim()}` : ""}
              {rangeStart || rangeEnd ? ` · 기간` : ""}
              {visibility !== "all" ? ` · ${visibility === "public" ? "공개" : "비공개"}` : ""}
            </span>

            {showTodayEmptyHint ? <span className="admin-sticky-hint">오늘 이벤트 없음</span> : null}

            <button type="button" className="admin-sticky-reset" onClick={resetFilters}>
              필터 초기화
            </button>
          </div>
        </div>

        {loading ? (
          <div className="p-12 text-center text-gray-500">불러오는 중...</div>
        ) : filteredAll.length === 0 ? (
          <div className="p-6">
            <EmptyState
              title="조건에 맞는 이벤트가 없습니다."
              description="필터를 초기화하거나, 새 이벤트를 등록해 보세요."
              actionLabel="+ 이벤트 등록하기"
              onAction={() => (window.location.href = "/admin/events/new")}
              className="shadow-none"
            />
          </div>
        ) : (
          <>
            <table className="admin-table w-full text-left">
              <thead className="bg-gray-50 text-gray-600 text-sm uppercase">
                <tr>
                  {/* ✅ 체크박스 컬럼 */}
                  <th className="admin-th px-4 py-4 font-semibold w-[52px]">
                    <input
                      ref={headerCbRef}
                      type="checkbox"
                      className="h-4 w-4"
                      checked={headerState.checked}
                      disabled={bulkBusy || headerState.disabled}
                      onChange={() => selection.toggleVisibleAll()}
                      aria-label="현재 페이지 전체 선택"
                      onClick={(e) => e.stopPropagation()}
                    />
                  </th>

                  <th className="admin-th px-6 py-4 font-semibold">구분</th>
                  <th className="admin-th px-6 py-4 font-semibold">상태</th>
                  <th className="admin-th px-6 py-4 font-semibold">이벤트</th>
                  <th className="admin-th px-6 py-4 font-semibold">날짜</th>
                  <th className="admin-th px-6 py-4 font-semibold">장소</th>
                  <th className="admin-th px-6 py-4 font-semibold text-right">관리</th>
                </tr>
              </thead>

              <tbody className="divide-y divide-gray-100">
                {paged.map((e) => {
                  const st = getStatus(e);
                  const modeVal = (e as any).mode;
                  const isFocus = focusId && (e as any).id === focusId;

                  const id = String((e as any)?.id || "");
                  const isActive = id && id === activeId;
                  const isPreviewing = previewOpen && previewEvent?.id && id === previewEvent.id;

                  const editTo = `/admin/events/${id}/edit?mode=${encodeURIComponent(modeVal || "explorer")}`;
                  const dateLabel = formatRange((e as any).date, (e as any).endDate || (e as any).date, { weekday: true });

                  const checked = selection.isSelected(id);

                  return (
                    <tr
                      key={id}
                      id={`event-row-${id}`}
                      className={[
                        "admin-tr hover:bg-gray-50 cursor-pointer",
                        checked ? "bg-emerald-50" : "",
                        isActive ? "bg-blue-50" : "",
                        isPreviewing ? "ring-2 ring-blue-200" : "",
                        isFocus ? "bg-yellow-50 ring-2 ring-yellow-200" : "",
                      ].join(" ")}
                      role="button"
                      tabIndex={0}
                      aria-label={`이벤트 선택: ${(e as any).title || ""}`}
                      onClick={() => openPreview(e)}
                      onFocus={() => setActiveId(id)}
                      onKeyDown={(ev) => {
                        if (ev.key === "Enter" || ev.key === " ") {
                          ev.preventDefault();
                          openPreview(e);
                        }
                      }}
                    >
                      {/* ✅ row checkbox */}
                      <td
                        className="admin-td px-4 py-4"
                        onClick={(ev) => ev.stopPropagation()}
                        onKeyDown={(ev) => ev.stopPropagation()}
                      >
                        <input
                          type="checkbox"
                          className="h-4 w-4"
                          checked={checked}
                          disabled={bulkBusy || !id}
                          onChange={(ev) => selection.setChecked(id, ev.target.checked)}
                          aria-label="행 선택"
                        />
                      </td>

                      <td className="admin-td px-6 py-4">
                        <span
                          className={`admin-chip px-2 py-1 rounded text-xs font-bold ${
                            modeVal === "nightlife" ? "bg-purple-100 text-purple-700" : "bg-blue-100 text-blue-700"
                          }`}
                        >
                          {modeVal === "nightlife" ? "Nightlife" : "Explorer"}
                        </span>
                      </td>

                      <td className="admin-td px-6 py-4">
                        <span
                          className={`admin-chip px-2 py-1 rounded text-xs font-bold ${
                            st === "active"
                              ? "bg-green-100 text-green-700"
                              : st === "past"
                                ? "bg-gray-100 text-gray-700"
                                : "bg-yellow-100 text-yellow-700"
                          }`}
                        >
                          {st === "active" ? "오늘" : st === "past" ? "종료" : "예정"}
                        </span>
                      </td>

                      <td className="admin-td px-6 py-4">
                        <div className="font-bold text-gray-800">{(e as any).title}</div>
                        <div className="text-xs text-gray-500 mt-1 flex gap-2 flex-wrap">
                          {(e as any).city ? (
                            <span className="admin-chip px-2 py-0.5 rounded bg-gray-100">{(e as any).city}</span>
                          ) : null}
                          {(e as any).category ? (
                            <span className="admin-chip px-2 py-0.5 rounded bg-gray-100">{(e as any).category}</span>
                          ) : null}
                        </div>
                        {(e as any).description ? (
                          <div className="text-xs text-gray-500 line-clamp-1 mt-1">{(e as any).description}</div>
                        ) : null}
                      </td>

                      <td className="admin-td px-6 py-4 text-sm text-gray-700">{dateLabel}</td>

                      <td className="admin-td px-6 py-4 text-sm text-gray-700">{(e as any).location}</td>

                      <td
                        className="admin-td px-6 py-4 text-right whitespace-nowrap"
                        onClick={(ev) => ev.stopPropagation()}
                        onKeyDown={(ev) => ev.stopPropagation()}
                      >
                        <EventRowActions
                          editTo={editTo}
                          onDuplicate={() => void handleDuplicate(e)}
                          onCopyLink={() => void copyAdminEditLink(e)}
                          onDelete={() => {
                            setDeleteTarget(e);
                            setDeleteText("");
                          }}
                          deleteConfirmTitle={String((e as any)?.title || "")}
                          deleteConfirmMeta={dateLabel}
                        />
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>

            <Pagination
              currentPage={page}
              totalPages={totalPages}
              onPageChange={(p) => setPage(clampInt(p, 1, totalPages, 1))}
            />
          </>
        )}
      </div>

      {/* 단건 삭제 모달 */}
      <Modal
        isOpen={!!deleteTarget}
        onClose={closeDeleteModal}
        title="이벤트 삭제"
        footer={
          <div className="flex gap-2">
            <button
              type="button"
              onClick={closeDeleteModal}
              className="px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-sm font-bold"
              disabled={deleting}
            >
              취소
            </button>
            <button
              type="button"
              onClick={() => void confirmDelete()}
              className="px-3 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-extrabold disabled:opacity-60"
              disabled={deleting || deleteText.trim() !== "DELETE"}
            >
              {deleting ? "삭제 중..." : "삭제"}
            </button>
          </div>
        }
      >
        {deleteTarget ? (
          <div className="space-y-3">
            <div className="rounded-lg border border-red-100 bg-red-50 p-3 text-sm text-red-800">
              <div className="font-extrabold">주의</div>
              <div className="mt-1">
                삭제하면 목록에서 제거됩니다. 실수 방지를 위해 <span className="font-extrabold">DELETE</span> 입력이
                필요합니다.
              </div>
              <div className="mt-1 text-xs text-red-700/80">삭제 후 6초 안에 Undo로 복구할 수 있어요.</div>
            </div>

            <div className="rounded-lg border border-gray-200 bg-white p-3 text-sm">
              <div className="font-extrabold text-gray-900 truncate">{(deleteTarget as any).title}</div>
              <div className="mt-1 text-xs text-gray-600">
                {(deleteTarget as any).mode === "nightlife" ? "Nightlife" : "Explorer"} ·{" "}
                {formatRange((deleteTarget as any).date, (deleteTarget as any).endDate || (deleteTarget as any).date, {
                  weekday: true,
                })}
              </div>
              {(deleteTarget as any).location ? (
                <div className="mt-1 text-xs text-gray-600 truncate">{(deleteTarget as any).location}</div>
              ) : null}
            </div>

            <div>
              <label className="block text-xs font-bold text-gray-700 mb-1">삭제하려면 DELETE 입력</label>
              <input
                value={deleteText}
                onChange={(e) => setDeleteText(e.target.value)}
                placeholder="DELETE"
                className="w-full px-3 py-2 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-red-500 font-mono"
                autoComplete="off"
                disabled={deleting}
              />
            </div>
          </div>
        ) : null}
      </Modal>

      {/* ✅ 벌크 삭제 모달 */}
      <Modal
        isOpen={bulkDeleteOpen}
        onClose={() => (!bulkBusy ? closeBulkDelete() : null)}
        title={`선택 ${selection.selectedCount}개 삭제`}
        footer={
          <div className="flex gap-2">
            <button
              type="button"
              onClick={closeBulkDelete}
              className="px-3 py-2 rounded-lg bg-gray-100 hover:bg-gray-200 text-sm font-bold"
              disabled={bulkBusy}
            >
              취소
            </button>
            <button
              type="button"
              onClick={() => void confirmBulkDelete()}
              className="px-3 py-2 rounded-lg bg-red-600 hover:bg-red-700 text-white text-sm font-extrabold disabled:opacity-60"
              disabled={bulkBusy || bulkDeleteText.trim() !== "DELETE"}
            >
              {bulkBusy ? "삭제 중..." : "삭제"}
            </button>
          </div>
        }
      >
        <div className="space-y-3">
          <div className="rounded-lg border border-red-100 bg-red-50 p-3 text-sm text-red-800">
            <div className="font-extrabold">주의</div>
            <div className="mt-1">
              총 <span className="font-extrabold">{selection.selectedCount}</span>개를 삭제합니다. 실수 방지를 위해{" "}
              <span className="font-extrabold">DELETE</span> 입력이 필요합니다.
            </div>
            <div className="mt-1 text-xs text-red-700/80">
              실패 항목은 자동으로 복구되며, 결과는 “성공/실패 요약”으로 안내됩니다.
            </div>
          </div>

          <div>
            <label className="block text-xs font-bold text-gray-700 mb-1">삭제하려면 DELETE 입력</label>
            <input
              value={bulkDeleteText}
              onChange={(e) => setBulkDeleteText(e.target.value)}
              placeholder="DELETE"
              className="w-full px-3 py-2 rounded-lg border border-gray-300 outline-none focus:ring-2 focus:ring-red-500 font-mono"
              autoComplete="off"
              disabled={bulkBusy}
            />
          </div>
        </div>
      </Modal>
    </div>
  );
}
