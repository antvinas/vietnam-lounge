// apps/web/src/features/admin/api/events/events.api.ts

import {
  collection,
  doc,
  getDoc,
  getDocs,
  addDoc,
  setDoc,
  updateDoc,
  deleteDoc,
  serverTimestamp,
  query,
  orderBy,
} from "firebase/firestore";

import { db, auth } from "@/lib/firebase";
import { formatYmd, toDateMaybe } from "@/features/admin/utils/datetime";

import type { AdminEventData, AdminMode, EventStatus, EventVisibility } from "../types";

// --------------------------------------------
// Internal helpers
// --------------------------------------------

const colForMode = (mode: AdminMode, base: string) => (mode === "nightlife" ? `adult_${base}` : base);

function isYmd(s: string) {
  return /^\d{4}-\d{2}-\d{2}$/.test(s);
}

function ymdToday() {
  return new Date().toISOString().slice(0, 10);
}

function normalizeVisibility(input: any): { isPublic?: boolean; visibility?: EventVisibility } {
  const v = input?.visibility;
  const p = input?.isPublic;

  if (v === "public") return { isPublic: true, visibility: "public" };
  if (v === "private") return { isPublic: false, visibility: "private" };
  if (typeof p === "boolean") return { isPublic: p, visibility: p ? "public" : "private" };
  return {};
}

function normalizeEventForStore(input: AdminEventData) {
  const date = isYmd(input.date) ? input.date : ymdToday();
  const endDate = input.endDate && isYmd(input.endDate) ? input.endDate : date;

  const title = String(input.title || "").trim();
  const description = String(input.description || "").trim();
  const location = String(input.location || "").trim();
  const city = input.city ? String(input.city) : undefined;
  const category = String(input.category || "Festival");
  const organizer = String(input.organizer || "");
  const imageUrl = String(input.imageUrl || "").trim();

  const gallery = Array.isArray(input.gallery) ? input.gallery.map((x) => String(x)).filter(Boolean) : undefined;

  const vis = normalizeVisibility(input);
  const status = input?.status ? String(input.status).trim() : undefined;

  return {
    mode: input.mode,
    title,
    name: title,
    description,
    location,
    city,
    category,
    organizer,
    imageUrl,
    image: imageUrl,
    gallery,
    date,
    endDate,
    ...(vis.visibility ? { visibility: vis.visibility } : {}),
    ...(typeof vis.isPublic === "boolean" ? { isPublic: vis.isPublic } : {}),
    ...(status ? { status } : {}),
    updatedAt: serverTimestamp(),
  };
}

async function firstDocOrNull(pathA: string, id: string, pathB?: string) {
  const refA = doc(db, pathA, id);
  const snapA = await getDoc(refA);
  if (snapA.exists()) return { ref: refA, snap: snapA, col: pathA };
  if (!pathB) return null;
  const refB = doc(db, pathB, id);
  const snapB = await getDoc(refB);
  if (snapB.exists()) return { ref: refB, snap: snapB, col: pathB };
  return null;
}

function normalizeEventDateToYmd(v: any): string {
  const d = toDateMaybe(v);
  if (d) return formatYmd(d);

  const s = String(v ?? "").trim();
  if (isYmd(s)) return s;

  const t = Date.parse(s);
  if (Number.isFinite(t)) return formatYmd(new Date(t));

  return "";
}

function chunk<T>(arr: T[], size: number) {
  const out: T[][] = [];
  for (let i = 0; i < arr.length; i += size) out.push(arr.slice(i, i + size));
  return out;
}

type ApiError = Error & { status?: number; url?: string; body?: string };

function apiPrefix() {
  // .env에서 VITE_API_URL=/api 형태로 사용 중 (vite proxy + hosting rewrite와 맞춤)
  const raw = String((import.meta as any).env?.VITE_API_URL || "/api");
  return raw.replace(/\/+$/, "") || "/api";
}

function buildApiUrl(pathWithQuery: string) {
  const p = apiPrefix();
  if (!pathWithQuery) return p;
  if (pathWithQuery.startsWith("http://") || pathWithQuery.startsWith("https://")) return pathWithQuery;
  if (pathWithQuery.startsWith("/")) return `${p}${pathWithQuery}`;
  return `${p}/${pathWithQuery}`;
}

async function adminFetchJson<T>(url: string): Promise<T> {
  const token = await auth.currentUser?.getIdToken();
  const res = await fetch(url, {
    method: "GET",
    headers: {
      ...(token ? { Authorization: `Bearer ${token}` } : {}),
      Accept: "application/json",
    },
  });

  if (!res.ok) {
    const txt = await res.text().catch(() => "");
    const err: ApiError = new Error(txt || `Request failed (${res.status})`) as ApiError;
    err.status = res.status;
    err.url = url;
    err.body = txt;
    throw err;
  }
  return (await res.json()) as T;
}

// --------------------------------------------
// ✅ Audit types + API
// --------------------------------------------

export type EventAuditLogItem = {
  id: string;
  action: string;

  targetType?: string | null;
  targetId?: string | null;

  // 서버가 kind를 내려주면 필터/뱃지에 바로 씀 (없으면 프론트에서 추론)
  kinds?: Array<"save" | "publish" | "image"> | null;

  changedFields?: string[] | null;
  before?: Record<string, any> | null;
  after?: Record<string, any> | null;

  byUid?: string | null;
  byEmail?: string | null;

  createdAt?: string | null;

  // ✅ raw payload (기존엔 프론트에서 null로 보여 “뭔가 이상”해 보이던 부분)
  data?: Record<string, any> | null;
};

export const getEventAuditTrail = async (
  eventId: string,
  opts?: { limit?: number; kind?: "all" | "save" | "publish" | "image" }
): Promise<EventAuditLogItem[]> => {
  const lim = Math.max(1, Math.min(200, Number(opts?.limit ?? 50)));
  const kind = String(opts?.kind ?? "all") as "all" | "save" | "publish" | "image";

  const id = encodeURIComponent(String(eventId));

  const params = new URLSearchParams();
  params.set("limit", String(lim));
  if (kind !== "all") params.set("kind", kind);

  const url = buildApiUrl(`/admin/events/${id}/audit?${params.toString()}`);

  const rows = await adminFetchJson<EventAuditLogItem[]>(url);
  return Array.isArray(rows) ? rows : [];
};

// --------------------------------------------
// Events API
// --------------------------------------------

export const getEvents = async (): Promise<AdminEventData[]> => {
  const [a, b] = await Promise.all([
    getDocs(query(collection(db, "events"), orderBy("date", "asc"))),
    getDocs(query(collection(db, "adult_events"), orderBy("date", "asc"))),
  ]);

  const mapSnap = (snap: any, mode: AdminMode) =>
    snap.docs.map((d: any) => {
      const data = d.data() || {};
      const start = normalizeEventDateToYmd(data.date);
      const endRaw = data.endDate ?? data.date;
      const end = normalizeEventDateToYmd(endRaw);
      const vis = normalizeVisibility(data);

      return {
        id: d.id,
        mode,
        title: String(data.title ?? data.name ?? ""),
        description: data.description,
        location: data.location,
        city: data.city,
        category: data.category,
        organizer: data.organizer,
        imageUrl: data.imageUrl ?? data.image,
        gallery: Array.isArray(data.gallery) ? data.gallery : undefined,
        date: start || "",
        endDate: end && end !== start ? end : undefined,
        ...(vis.visibility ? { visibility: vis.visibility } : {}),
        ...(typeof vis.isPublic === "boolean" ? { isPublic: vis.isPublic } : {}),
        ...(data?.status ? { status: String(data.status) } : {}),
      } as AdminEventData;
    });

  return [...mapSnap(a, "explorer"), ...mapSnap(b, "nightlife")].sort((x, y) => (x.date || "").localeCompare(y.date || ""));
};

export const getEventById = async (id: string): Promise<AdminEventData | null> => {
  const found = await firstDocOrNull("events", id, "adult_events");
  if (!found) return null;

  const mode: AdminMode = found.col === "adult_events" ? "nightlife" : "explorer";
  const data: any = found.snap.data() || {};
  const start = normalizeEventDateToYmd(data.date);
  const endRaw = data.endDate ?? data.date;
  const end = normalizeEventDateToYmd(endRaw);
  const vis = normalizeVisibility(data);

  return {
    id,
    mode,
    title: String(data.title ?? data.name ?? ""),
    description: data.description,
    location: data.location,
    city: data.city,
    category: data.category,
    organizer: data.organizer,
    imageUrl: data.imageUrl ?? data.image,
    gallery: Array.isArray(data.gallery) ? data.gallery : undefined,
    date: start || "",
    endDate: end && end !== start ? end : undefined,
    ...(vis.visibility ? { visibility: vis.visibility } : {}),
    ...(typeof vis.isPublic === "boolean" ? { isPublic: vis.isPublic } : {}),
    ...(data?.status ? { status: String(data.status) } : {}),
  };
};

export const addEvent = async (input: AdminEventData) => {
  const colName = colForMode(input.mode, "events");
  const payload = normalizeEventForStore(input);
  const docRef = await addDoc(collection(db, colName), { ...payload, createdAt: serverTimestamp() });
  return { id: docRef.id };
};

export const updateEvent = async (id: string, input: AdminEventData) => {
  const desiredCol = colForMode(input.mode, "events");
  const otherCol = desiredCol === "events" ? "adult_events" : "events";
  const payload = normalizeEventForStore(input);

  const desired = doc(db, desiredCol, id);
  const desiredSnap = await getDoc(desired);
  if (desiredSnap.exists()) {
    await updateDoc(desired, payload as any);
    return { ok: true, moved: false };
  }

  const other = doc(db, otherCol, id);
  const otherSnap = await getDoc(other);
  if (otherSnap.exists()) {
    const prev = otherSnap.data() || {};
    await setDoc(desired, { ...prev, ...payload, movedAt: serverTimestamp() }, { merge: true });
    await deleteDoc(other);
    return { ok: true, moved: true };
  }

  await setDoc(desired, { ...payload, createdAt: serverTimestamp() }, { merge: true });
  return { ok: true, moved: false, created: true };
};

export const deleteEvent = async (id: string) => {
  const found = await firstDocOrNull("events", id, "adult_events");
  if (!found) return { ok: true };
  await deleteDoc(found.ref);
  return { ok: true, mode: found.col === "adult_events" ? "nightlife" : "explorer" };
};

export const bulkDeleteEvents = async (ids: string[]) => {
  const uniqIds = Array.from(new Set((ids || []).map((x) => String(x).trim()).filter(Boolean)));
  if (!uniqIds.length) return { ok: true, deleted: 0, results: [] as any[] };

  const results: Array<{ id: string; ok: boolean; mode?: AdminMode; error?: string }> = [];
  const chunks = chunk(uniqIds, 10);

  for (const group of chunks) {
    const settled = await Promise.allSettled(
      group.map(async (id) => {
        const found = await firstDocOrNull("events", id, "adult_events");
        if (!found) {
          results.push({ id, ok: false, error: "not_found" });
          return;
        }
        await deleteDoc(found.ref);
        results.push({ id, ok: true, mode: found.col === "adult_events" ? "nightlife" : "explorer" });
      })
    );

    settled.forEach((s, idx) => {
      if (s.status === "rejected") {
        const id = group[idx];
        if (!results.some((r) => r.id === id)) results.push({ id, ok: false, error: String((s as any).reason || "failed") });
      }
    });
  }

  return { ok: true, deleted: results.filter((r) => r.ok).length, results };
};

export const bulkUpdateEvents = async (ids: string[], patch: Partial<AdminEventData> & Record<string, any>) => {
  const uniqIds = Array.from(new Set((ids || []).map((x) => String(x).trim()).filter(Boolean)));
  if (!uniqIds.length) return { ok: true, updated: 0, results: [] as any[] };

  const results: Array<{ id: string; ok: boolean; moved?: boolean; error?: string }> = [];
  const chunks = chunk(uniqIds, 10);

  for (const group of chunks) {
    const settled = await Promise.allSettled(
      group.map(async (id) => {
        const found = await firstDocOrNull("events", id, "adult_events");
        if (!found) {
          results.push({ id, ok: false, error: "not_found" });
          return;
        }

        const mode: AdminMode = found.col === "adult_events" ? "nightlife" : "explorer";
        const data: any = found.snap.data() || {};
        const vis = normalizeVisibility(data);

        const current: AdminEventData = {
          id,
          mode,
          title: String(data.title ?? data.name ?? ""),
          description: data.description,
          location: data.location,
          city: data.city,
          category: data.category,
          organizer: data.organizer,
          imageUrl: data.imageUrl ?? data.image,
          gallery: Array.isArray(data.gallery) ? data.gallery : undefined,
          date: normalizeEventDateToYmd(data.date) || "",
          endDate: (() => {
            const end = normalizeEventDateToYmd(data.endDate ?? data.date);
            const start = normalizeEventDateToYmd(data.date);
            return end && start && end !== start ? end : undefined;
          })(),
          ...(vis.visibility ? { visibility: vis.visibility } : {}),
          ...(typeof vis.isPublic === "boolean" ? { isPublic: vis.isPublic } : {}),
          ...(data?.status ? { status: String(data.status) } : {}),
        };

        const next: AdminEventData = {
          ...current,
          ...patch,
          mode: (patch as any)?.mode ?? current.mode,
          date: normalizeEventDateToYmd((patch as any)?.date ?? current.date) || current.date,
          endDate: (() => {
            const v = (patch as any)?.endDate ?? current.endDate ?? (patch as any)?.date ?? current.date;
            const end = normalizeEventDateToYmd(v);
            const start = normalizeEventDateToYmd((patch as any)?.date ?? current.date) || current.date;
            if (!end) return undefined;
            return end !== start ? end : undefined;
          })(),
        };

        const r = await updateEvent(id, next);
        results.push({ id, ok: true, moved: Boolean((r as any)?.moved) });
      })
    );

    settled.forEach((s, idx) => {
      if (s.status === "rejected") {
        const id = group[idx];
        if (!results.some((r) => r.id === id)) results.push({ id, ok: false, error: String((s as any).reason || "failed") });
      }
    });
  }

  return { ok: true, updated: results.filter((r) => r.ok).length, results };
};

export const duplicateEvent = async (
  id: string,
  opts?: { resetDateToToday?: boolean; makePrivate?: boolean; makeDraft?: boolean }
) => {
  const resetDateToToday = opts?.resetDateToToday ?? true;
  const makePrivate = opts?.makePrivate ?? true;
  const makeDraft = opts?.makeDraft ?? true;

  const found = await firstDocOrNull("events", id, "adult_events");
  if (!found) throw new Error("Event not found");

  const mode: AdminMode = found.col === "adult_events" ? "nightlife" : "explorer";
  const raw: any = found.snap.data() || {};

  const src: AdminEventData = {
    id,
    mode,
    title: String(raw.title ?? raw.name ?? ""),
    description: raw.description,
    location: raw.location,
    city: raw.city,
    category: raw.category,
    organizer: raw.organizer,
    imageUrl: raw.imageUrl ?? raw.image,
    gallery: Array.isArray(raw.gallery) ? raw.gallery : undefined,
    date: normalizeEventDateToYmd(raw.date) || "",
    endDate: (() => {
      const start = normalizeEventDateToYmd(raw.date);
      const end = normalizeEventDateToYmd(raw.endDate ?? raw.date);
      if (!end) return undefined;
      return start && end !== start ? end : undefined;
    })(),
    ...normalizeVisibility(raw),
    ...(raw?.status ? { status: String(raw.status) } : {}),
  };

  const today = ymdToday();
  const nextDate = resetDateToToday ? today : src.date || today;

  const copy: AdminEventData = {
    mode: src.mode,
    title: `${String(src.title || "").trim()} (복제)`,
    description: src.description,
    location: src.location,
    city: src.city,
    category: src.category,
    organizer: src.organizer,
    imageUrl: src.imageUrl,
    gallery: src.gallery,
    date: nextDate,
    endDate: undefined,
    ...(makePrivate ? { isPublic: false, visibility: "private" as EventVisibility } : {}),
    ...(makeDraft ? { status: "draft" as EventStatus } : {}),
  };

  const created = await addEvent(copy);
  return { id: created.id, mode: copy.mode };
};
