// apps/web/src/features/admin/api/users/users.api.ts

import type { User } from "@/types/user";
import { safeDelete, safeGet, safePatch } from "../http";

/**
 * ✅ Admin Users API
 * Backend: /api/admin/users (firebase/functions/src/api/admin/users.router.ts)
 */

export const getUsers = async (): Promise<User[]> => {
  return await safeGet<User[]>("admin/users");
};

export const updateUserRole = async (uid: string, role: "admin" | "user") => {
  if (!uid) throw new Error("uid is required");
  return await safePatch<{ ok: true }>(`admin/users/${uid}/role`, {
    admin: role === "admin",
  });
};

export const updateUserStatus = async (uid: string, status: "active" | "banned", memo?: string) => {
  if (!uid) throw new Error("uid is required");
  return await safePatch<{ ok: true }>(`admin/users/${uid}/status`, {
    active: status === "active",
    ...(memo ? { memo } : {}),
  });
};

export const deleteUser = async (uid: string) => {
  if (!uid) throw new Error("uid is required");
  return await safeDelete<{ ok: true }>(`admin/users/${uid}`);
};
