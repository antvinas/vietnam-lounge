// apps/web/src/features/admin/api/http.ts
// ✅ Admin API 공통 HTTP 유틸 (baseURL /api 유지 + 타입 안전)

import { client } from "@/lib/api";

/**
 * ✅ Axios baseURL이 "/api" 또는 "https://.../api"일 때,
 * client.get("/admin/...") 처럼 "/"로 시작하면 "/api"가 날아가 버린다.
 * -> 항상 "admin/..." 형태로 보정해서 baseURL 뒤에 붙도록 한다.
 */
export function normalizeApiPath(path: string) {
  const p = String(path || "").trim();
  if (!p) return p;
  if (/^https?:\/\//i.test(p)) return p; // 절대 URL은 그대로
  return p.replace(/^\/+/, ""); // 선행 "/" 제거
}

export async function safeGet<T = any>(path: string, params?: any) {
  const res = await client.get(normalizeApiPath(path), { params });
  return res.data as T;
}

export async function safePost<T = any>(path: string, body?: any) {
  const res = await client.post(normalizeApiPath(path), body ?? {});
  return res.data as T;
}

export async function safePut<T = any>(path: string, body?: any) {
  const res = await client.put(normalizeApiPath(path), body ?? {});
  return res.data as T;
}

export async function safePatch<T = any>(path: string, body?: any) {
  const res = await client.patch(normalizeApiPath(path), body ?? {});
  return res.data as T;
}

export async function safeDelete<T = any>(path: string, params?: any) {
  const res = await client.delete(normalizeApiPath(path), { params });
  return res.data as T;
}

// --------------------------------------------
// Common small utils (API layer safe-belts)
// --------------------------------------------

export function clampInt(n: any, min: number, max: number, fallback: number) {
  const v = Number.isFinite(Number(n)) ? Number(n) : fallback;
  return Math.min(max, Math.max(min, Math.trunc(v)));
}

export function clampNumber(n: any, min: number, max: number): number | undefined {
  const v = Number(n);
  if (!Number.isFinite(v)) return undefined;
  return Math.min(max, Math.max(min, v));
}

export function normalizeText(v: any): string | undefined {
  const s = String(v ?? "").trim();
  return s ? s : undefined;
}
