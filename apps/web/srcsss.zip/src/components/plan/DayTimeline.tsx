// apps/web/src/components/plan/DayTimeline.tsx
import React, { useMemo } from "react";
import { useNavigate, useLocation } from "react-router-dom";
import { shallow } from "zustand/shallow";
import {
  DragDropContext,
  Droppable,
  Draggable,
} from "@hello-pangea/dnd";

import { usePlanStore } from "@/store/plan.store";
import { usePlanUIStore } from "@/store/plan.ui.store";
import TimelineItem, {
  TimelineItemData,
} from "@/components/plan/TimelineItem";
import useUndo from "@/hooks/useUndo";
import { useDayTimelineDnd } from "@/hooks/usePlanDnd";

export default function DayTimeline() {
  const navigate = useNavigate();
  const location = useLocation();

  const currentDayId = usePlanUIStore((s) => s.currentDayId);
  const setHoverSpotId = usePlanUIStore((s) => s.setHoverSpotId);

  const { rawItems, removeItem, addItem } = usePlanStore(
    (s) => ({
      rawItems: Object.values(s.items)
        .filter((it: any) => it.dayId === currentDayId)
        .sort(
          (a: any, b: any) =>
            (a.timeStartMin ?? 0) - (b.timeStartMin ?? 0)
        ),
      removeItem: s.removeItem,
      addItem: s.addItem,
    }),
    shallow
  );

  const items: TimelineItemData[] = useMemo(
    () =>
      rawItems.map((it: any) => ({
        id: it.id as string,
        title: it.title as string,
        type: (it.type as any) ?? "custom",
        placeName: (it.placeName ??
          it.placeTitle ??
          it.locationName) as string,
        timeStartMin: it.timeStartMin as number | undefined,
        timeEndMin: it.timeEndMin as number | undefined,
        cost: it.cost as number | undefined,
      })),
    [rawItems]
  );

  const { deleteWithUndo } = useUndo();

  /** 삭제 + Undo */
  const handleRemove = (id: string) => {
    const target = rawItems.find((it: any) => it.id === id);
    if (!target) return;

    // 스냅샷(스토어 Item 구조 그대로)
    const snapshot = { ...target };

    deleteWithUndo({
      label: snapshot.title ?? "일정",
      onDelete: () => {
        removeItem(id);
      },
      onRestore: () => {
        // 같은 id/시간/dayId로 복원
        addItem(snapshot);
      },
      duration: 5000,
    });
  };

  const handleAddPlace = () => {
    if (!currentDayId) {
      window.alert("먼저 일정을 선택한 뒤 장소를 추가해 주세요.");
      return;
    }
    const searchPath = `/plan/search?dayId=${encodeURIComponent(
      currentDayId
    )}`;
    navigate(searchPath, {
      state: { backgroundLocation: location, background: location },
    });
  };

  // DnD 훅 (현재 Day 기준으로 순서 변경)
  const { onDragEnd } = useDayTimelineDnd(currentDayId ?? null);

  return (
    <div className="px-2 py-3">
      <div className="mb-2 flex items-center justify-between">
        <div className="text-sm font-semibold">일정</div>
        <button
          className="rounded-md border border-slate-200 px-2 py-1 text-[11px] text-slate-600 hover:bg-slate-50 dark:border-slate-700 dark:text-slate-300 dark:hover:bg-slate-800"
          onClick={() =>
            (window as any)?.toast?.info?.(
              "정렬/필터는 준비 중입니다."
            )
          }
        >
          정렬/필터
        </button>
      </div>

      <DragDropContext onDragEnd={onDragEnd}>
        <Droppable
          droppableId={currentDayId ?? "current-day"}
        >
          {(droppableProvided) => (
            <div
              ref={droppableProvided.innerRef}
              {...droppableProvided.droppableProps}
              role="list"
              className="space-y-2"
            >
              {items.map((it, index) => (
                <Draggable
                  key={it.id}
                  draggableId={it.id}
                  index={index}
                >
                  {(dragProvided, snapshot) => (
                    <div
                      ref={dragProvided.innerRef}
                      {...dragProvided.draggableProps}
                    >
                      <TimelineItem
                        item={it}
                        onHoverChange={(id) =>
                          setHoverSpotId(id)
                        }
                        onRemove={handleRemove}
                        // 실제 드래그는 래퍼 div가 맡고,
                        // 핸들은 TimelineItem 안 ⋮⋮ 버튼에 연결
                        dragHandleProps={
                          dragProvided.dragHandleProps ?? undefined
                        }
                      />
                    </div>
                  )}
                </Draggable>
              ))}

              {droppableProvided.placeholder}

              {items.length === 0 && (
                <div className="mt-2 rounded-lg border border-dashed border-slate-300 p-3 text-center text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">
                  아직 추가된 장소가 없어요. 아래 “장소 추가”로
                  시작해 보세요.
                </div>
              )}
            </div>
          )}
        </Droppable>
      </DragDropContext>

      <div className="mt-3">
        <button
          className="w-full rounded-md bg-emerald-500 px-3 py-2 text-sm text-white hover:bg-emerald-600"
          onClick={handleAddPlace}
        >
          + 장소 추가
        </button>
      </div>
    </div>
  );
}
