// src/components/plan/BudgetWidget.tsx
// 카테고리/일자 합계와 통화 표시. 정규화 스토어 셀렉터 사용.
// 6단계: variant="summary" 추가 → PlanSummaryBar 안에서 칩 형태로 사용 가능.
import { useEffect, useMemo, useState } from "react";
import {
  usePlanStore,
  selectCurrentTrip,
  selectDaysOfTrip,
  selectItemsOfDay,
  selectBudgetLeft,
} from "@/store/plan.store";

type Code = "VND" | "KRW" | "USD";
type RateMap = Record<Code, number>; // units per EUR

export type BudgetWidgetVariant = "panel" | "summary";

type Props = {
  defaultCurrency?: Code;
  budgetLimitVND?: number;
  /** "panel" = 기존 카드형, "summary" = PlanSummaryBar 칩 모드 */
  variant?: BudgetWidgetVariant;
  className?: string;
};

export default function BudgetWidget({
  defaultCurrency,
  budgetLimitVND,
  variant = "panel",
  className,
}: Props) {
  const trip = usePlanStore(selectCurrentTrip);
  const tripId = trip?.id;

  // trip 단위 day 리스트
  const days = usePlanStore((s) =>
    tripId ? selectDaysOfTrip(s, tripId) ?? [] : []
  );

  // 모든 day의 items 수집
  const allItems = usePlanStore((s) => {
    if (!tripId) return [];
    const dlist = selectDaysOfTrip(s, tripId) ?? [];
    const items = dlist.flatMap((d) => selectItemsOfDay(s, d.id) ?? []);
    return items;
  });

  // 잔여 예산
  const budgetLeft = usePlanStore((s) =>
    tripId ? selectBudgetLeft(s, tripId) : 0
  );

  // 통화(표시용 로컬 상태). 스토어에 영구 반영 API가 있으면 연결
  const [cur, setCur] = useState<Code>(
    (trip?.currency as Code) || defaultCurrency || "VND"
  );

  // 환율 로딩
  const [rates, setRates] = useState<RateMap | null>(null);
  const [err, setErr] = useState<string | null>(null);

  useEffect(() => {
    let ignore = false;
    (async () => {
      try {
        const r = await fetchFrankfurter(["KRW", "VND", "USD"]);
        if (!ignore) setRates({ KRW: r.KRW, VND: r.VND, USD: r.USD });
      } catch {
        try {
          const r2 = await fetchExchangerateHost(["KRW", "VND", "USD"]);
          if (!ignore) setRates({ KRW: r2.KRW, VND: r2.VND, USD: r2.USD });
        } catch {
          if (!ignore)
            setErr("환율을 불러오지 못했습니다. 변환값은 참고용입니다.");
        }
      }
    })();
    return () => {
      ignore = true;
    };
  }, []);

  // dayId → 날짜 라벨 매핑(가능한 키 우선순위)
  const dayLabelMap = useMemo(() => {
    const m = new Map<string, string>();
    for (const d of days) {
      const label =
        (d as any).dateISO ||
        (d as any).date ||
        (d as any).key ||
        String((d as any).order ?? (d as any).id);
      m.set((d as any).id, label);
    }
    return m;
  }, [days]);

  // 카테고리/일자 합계
  const { totalVND, byCategory, byDate } = useMemo(() => {
    const catAgg: Record<string, number> = {};
    const dateAgg: Record<string, number> = {};
    let sum = 0;
    for (const it of allItems) {
      const cost =
        typeof (it as any).cost === "number" ? (it as any).cost : 0;
      const ckey =
        (it as any).category ||
        (it as any).meta?.category ||
        ((it as any).type === "move"
          ? "transport"
          : (it as any).type || "misc");
      const dkey = dayLabelMap.get((it as any).dayId) ?? "기타";
      sum += cost;
      catAgg[ckey] = (catAgg[ckey] ?? 0) + cost;
      dateAgg[dkey] = (dateAgg[dkey] ?? 0) + cost;
    }
    return { totalVND: sum, byCategory: catAgg, byDate: dateAgg };
  }, [allItems, dayLabelMap]);

  const vndTo = useMemo(() => {
    if (!rates) return 1;
    if (cur === "VND") return 1;
    return rates[cur] / rates.VND; // 1 VND → target
  }, [rates, cur]);

  const fmt = (v: number) => {
    const n = Math.round(v * (cur === "VND" ? 1 : vndTo));
    const locale =
      cur === "KRW" ? "ko-KR" : cur === "USD" ? "en-US" : "vi-VN";
    return new Intl.NumberFormat(locale, {
      style: "currency",
      currency: cur,
      maximumFractionDigits: 0,
    }).format(n);
  };

  const over =
    typeof budgetLimitVND === "number" && totalVND > budgetLimitVND;

  /** ─────────────────── 요약 칩 모드 (PlanSummaryBar 용) ─────────────────── */
  if (variant === "summary") {
    // 아무 데이터도 없으면 굳이 안 보여줘도 되지만,
    // 일단 0/0 상태라도 노출해서 구조 일관성 유지
    return (
      <div className={className ?? "flex flex-wrap items-center gap-2"}>
        <div className="summary-chip">
          <span className="summary-chip__label">사용한 예산</span>
          <span className="summary-chip__value">
            {fmt(totalVND || 0)}
          </span>
        </div>
        <div
          className={
            "summary-chip" + (over ? " danger" : "")
          }
        >
          <span className="summary-chip__label">남은 예산</span>
          <span className="summary-chip__value">
            {fmt(budgetLeft || 0)}
          </span>
        </div>
        <select
          className="ml-1 rounded-md border bg-transparent px-1.5 py-1 text-xs"
          value={cur}
          onChange={(e) => setCur(e.target.value as Code)}
          aria-label="통화"
        >
          <option value="VND">VND</option>
          <option value="KRW">KRW</option>
          <option value="USD">USD</option>
        </select>
        {err && (
          <span className="ml-1 text-[10px] text-amber-500">
            {err}
          </span>
        )}
      </div>
    );
  }

  /** ─────────────────── 전체 패널 모드 (기존 UI) ─────────────────── */
  const rootClass =
    className ??
    "rounded-xl border border-slate-200 bg-white p-4 dark:border-slate-700 dark:bg-slate-800";

  return (
    <div className={rootClass}>
      <header className="flex items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <h3 className="font-semibold">예산</h3>
          {over && (
            <span className="rounded-full bg-rose-500/15 px-2 py-0.5 text-xs text-rose-600 dark:text-rose-300">
              총합 초과
            </span>
          )}
        </div>
        <div className="flex items-center gap-2">
          <select
            className="rounded border bg-transparent px-2 py-1 text-sm"
            value={cur}
            onChange={(e) => setCur(e.target.value as Code)}
            aria-label="통화"
          >
            <option value="VND">VND</option>
            <option value="KRW">KRW</option>
            <option value="USD">USD</option>
          </select>
          <div className="text-sm text-slate-600 dark:text-slate-300">
            {fmt(totalVND)}
          </div>
          <div className="text-xs opacity-70">
            잔여: {fmt(budgetLeft)} {cur}
          </div>
        </div>
      </header>

      {err && <p className="mt-2 text-xs text-amber-500">{err}</p>}

      <section className="mt-3">
        <p className="mb-1 text-xs text-slate-500 dark:text-slate-400">
          카테고리
        </p>
        <ul className="space-y-1">
          {Object.entries(byCategory)
            .sort((a, b) => b[1] - a[1])
            .map(([k, v]) => (
              <li
                key={k}
                className="flex items-center justify-between text-sm"
              >
                <span className="capitalize text-slate-600 dark:text-slate-300">
                  {k}
                </span>
                <span className="font-medium">{fmt(v)}</span>
              </li>
            ))}
          {Object.keys(byCategory).length === 0 && (
            <li className="text-sm text-slate-500 dark:text-slate-400">
              비용 항목 없음
            </li>
          )}
        </ul>
      </section>

      <section className="mt-4">
        <p className="mb-1 text-xs text-slate-500 dark:text-slate-400">
          일자별 소계
        </p>
        <ul className="space-y-1">
          {Object.entries(byDate)
            .sort(([a], [b]) => a.localeCompare(b))
            .map(([d, v]) => (
              <li
                key={d}
                className="flex items-center justify-between text-sm"
              >
                <span className="text-slate-600 dark:text-slate-300">
                  {d}
                </span>
                <span className="font-medium">{fmt(v)}</span>
              </li>
            ))}
          {Object.keys(byDate).length === 0 && (
            <li className="text-sm text-slate-500 dark:text-slate-400">
              첫 장소를 추가하세요
            </li>
          )}
        </ul>
      </section>
    </div>
  );
}

async function fetchFrankfurter(codes: Code[]): Promise<RateMap> {
  const query = codes.join(",");
  const r1 = await fetch(
    `https://api.frankfurter.dev/latest?from=EUR&to=${query}`
  );
  if (r1.ok) {
    const j = await r1.json();
    if (j?.rates) return j.rates as RateMap;
  }
  const r2 = await fetch(
    `https://api.frankfurter.app/latest?from=EUR&to=${query}`
  );
  if (r2.ok) {
    const j = await r2.json();
    if (j?.rates) return j.rates as RateMap;
  }
  throw new Error("Frankfurter failed");
}

async function fetchExchangerateHost(codes: Code[]): Promise<RateMap> {
  const query = codes.join(",");
  const r = await fetch(
    `https://api.exchangerate.host/latest?base=EUR&symbols=${query}`
  );
  if (!r.ok) throw new Error("exchangerate.host failed");
  const j = await r.json();
  return j?.rates as RateMap;
}
