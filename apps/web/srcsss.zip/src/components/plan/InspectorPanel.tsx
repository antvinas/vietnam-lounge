// src/components/plan/InspectorPanel.tsx
/**
 * InspectorPanel
 * - 선택 아이템 시간/체류/비용/메모 편집
 * - 포커스 트랩/ESC 닫기/라이브 공지 적용
 * - 스토어 셀렉터를 실제 상태키에 맞춰 통일(s.items)  ← S3 정합성 수정
 */
import React, { useMemo, useRef, useState } from "react";
import { useFocusTrap } from "@/utils/a11y/useFocusTrap";
import { announce } from "@/utils/a11y/ariaLive";

import { usePlanStore } from "@/store/plan.store";
import { usePlanUIStore } from "@/store/plan.ui.store";

type ItemId = string;

type EditableItem = {
  id: ItemId;
  title?: string;
  note?: string;
  cost?: number;
  startTime?: string; // "HH:MM"
  endTime?: string;   // "HH:MM"
  stayMinutes?: number;
  placeId?: string;
  lat?: number;
  lng?: number;
};

function pad2(n: number) {
  return n.toString().padStart(2, "0");
}
function toTimeString(minutes: number | undefined): string {
  if (minutes == null || Number.isNaN(minutes)) return "";
  const h = Math.floor(minutes / 60);
  const m = Math.max(0, Math.round(minutes - h * 60));
  return `${pad2(h)}:${pad2(m)}`;
}
function toMinutes(hhmm: string | undefined): number | undefined {
  if (!hhmm) return undefined;
  const [h, m] = hhmm.split(":").map((v) => parseInt(v, 10));
  if (Number.isNaN(h) || Number.isNaN(m)) return undefined;
  return h * 60 + m;
}

export default function InspectorPanel() {
  const containerRef = useRef<HTMLDivElement>(null);
  const firstInputRef = useRef<HTMLInputElement>(null);

  const selectedItemId = usePlanUIStore((s) => s.selectedItemId as ItemId | null);
  const setSelectedItemId = usePlanUIStore((s) => s.setSelectedItemId as (id: ItemId | null) => void);

  // ✅ 실제 스토어 키(s.items)로 통일
  const item = usePlanStore((s: any) =>
    selectedItemId ? (s.items?.[selectedItemId] as EditableItem) : null
  );
  const updateItem = usePlanStore(
    (s: any) => s.updateItem as (id: ItemId, patch: Partial<EditableItem>) => void
  );

  const isOpen = !!selectedItemId && !!item;

  useFocusTrap({
    containerRef,
    initialFocusRef: firstInputRef,
    enabled: isOpen,
    onEscape: () => setSelectedItemId(null),
  });

  // 로컬 입력 상태
  const [local, setLocal] = useState<Partial<EditableItem>>({});

  React.useEffect(() => {
    if (!isOpen || !item) return;
    setLocal({
      title: item.title ?? "",
      note: item.note ?? "",
      cost: item.cost ?? 0,
      startTime: item.startTime ?? "",
      endTime: item.endTime ?? "",
      stayMinutes: item.stayMinutes ?? undefined,
    });
  }, [isOpen, item?.id]);

  const headerTitle = item?.title || "아이템 편집";

  const derivedStay = useMemo(() => {
    const s = toMinutes(local.startTime);
    const e = toMinutes(local.endTime);
    if (s != null && e != null && e >= s) return e - s;
    return local.stayMinutes;
  }, [local.startTime, local.endTime, local.stayMinutes]);

  const derivedEnd = useMemo(() => {
    const s = toMinutes(local.startTime);
    if (s != null && local.stayMinutes != null) {
      return toTimeString(s + local.stayMinutes);
    }
    return local.endTime ?? "";
  }, [local.startTime, local.stayMinutes, local.endTime]);

  function onChange<K extends keyof EditableItem>(key: K, value: EditableItem[K]) {
    setLocal((prev) => ({ ...prev, [key]: value }));
  }

  function save() {
    if (!item) return;
    const patch: Partial<EditableItem> = {
      title: local.title,
      note: local.note,
      cost: Number.isFinite(local.cost as number) ? Number(local.cost) : undefined,
      startTime: local.startTime,
      endTime: derivedEnd || local.endTime,
      stayMinutes: derivedStay,
    };
    updateItem(item.id, patch);
    announce("변경 사항 저장됨.");
  }

  function close() {
    setSelectedItemId(null);
  }

  if (!isOpen) return null;

  return (
    <aside
      ref={containerRef}
      role="dialog"
      aria-modal="true"
      aria-labelledby="inspector-title"
      aria-describedby="inspector-desc"
      className="fixed top-0 right-0 h-[100dvh] w-full max-w-[380px] bg-white dark:bg-slate-900 border-l border-slate-200 dark:border-slate-700 shadow-2xl z-[60] flex flex-col"
    >
      {/* Header */}
      <div className="summary-sticky flex items-center justify-between px-4 py-3 border-b border-slate-200 dark:border-slate-700">
        <div className="flex flex-col">
          <h2 id="inspector-title" className="text-sm font-semibold">
            {headerTitle}
          </h2>
          <p id="inspector-desc" className="text-xs text-slate-500 dark:text-slate-400">
            시작·종료·체류·비용·메모를 수정하세요. Esc로 닫기.
          </p>
        </div>
        <button className="summary-chip" onClick={close} aria-label="세부편집 닫기">
          닫기
        </button>
      </div>

      {/* Body */}
      <form
        className="flex-1 overflow-y-auto p-4 space-y-4"
        onSubmit={(e) => {
          e.preventDefault();
          save();
        }}
      >
        {/* 제목 */}
        <label className="block text-xs font-medium">
          제목
          <input
            ref={firstInputRef}
            className="mt-1 w-full rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-2 py-2"
            type="text"
            value={local.title ?? ""}
            onChange={(e) => onChange("title", e.target.value)}
          />
        </label>

        {/* 시간 */}
        <div className="grid grid-cols-2 gap-3">
          <label className="block text-xs font-medium">
            시작
            <input
              className="mt-1 w-full rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-2 py-2"
              type="time"
              value={local.startTime ?? ""}
              onChange={(e) => onChange("startTime", e.target.value)}
            />
          </label>
          <label className="block text-xs font-medium">
            종료
            <input
              className="mt-1 w-full rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-2 py-2"
              type="time"
              value={derivedEnd}
              onChange={(e) => onChange("endTime", e.target.value)}
            />
          </label>
        </div>

        {/* 체류 */}
        <div className="grid grid-cols-[1fr_auto_auto] gap-3 items-end">
          <label className="block text-xs font-medium">
            체류(분)
            <input
              className="mt-1 w-full rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-2 py-2"
              type="number"
              inputMode="numeric"
              min={0}
              step={5}
              value={derivedStay ?? ""}
              onChange={(e) =>
                onChange(
                  "stayMinutes",
                  e.target.value ? parseInt(e.target.value, 10) : undefined
                )
              }
            />
          </label>
          <button
            type="button"
            className="summary-chip"
            onClick={() =>
              onChange("stayMinutes", Math.max(0, (local.stayMinutes ?? 0) - 30))
            }
          >
            -30
          </button>
          <button
            type="button"
            className="summary-chip"
            onClick={() => onChange("stayMinutes", (local.stayMinutes ?? 0) + 30)}
          >
            +30
          </button>
        </div>

        {/* 비용 */}
        <label className="block text-xs font-medium">
          비용(통화 설정 기준)
          <input
            className="mt-1 w-full rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-2 py-2"
            type="number"
            inputMode="decimal"
            step="0.01"
            value={Number(local.cost ?? 0)}
            onChange={(e) =>
              onChange("cost", e.target.value === "" ? 0 : Number(e.target.value))
            }
          />
        </label>

        {/* 메모 */}
        <label className="block text-xs font-medium">
          메모
          <textarea
            className="mt-1 w-full min-h-[96px] rounded border border-slate-300 dark:border-slate-600 bg-white dark:bg-slate-800 px-2 py-2"
            value={local.note ?? ""}
            onChange={(e) => onChange("note", e.target.value)}
          />
        </label>
      </form>

      {/* Footer */}
      <div className="border-t border-slate-200 dark:border-slate-700 p-3 flex gap-2 justify-end">
        <button className="summary-chip" onClick={close}>
          취소
        </button>
        <button
          className="summary-chip warn"
          onClick={() => {
            save();
            close();
          }}
        >
          저장
        </button>
      </div>
    </aside>
  );
}
