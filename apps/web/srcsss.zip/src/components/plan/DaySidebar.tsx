// src/components/plan/DaySidebar.tsx
import React, { useEffect, useMemo } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { shallow } from "zustand/shallow";

import DayTimeline from "@/components/plan/DayTimeline";

import {
  usePlanStore,
  selectCurrentTrip,
  selectDaysOfTrip,
} from "@/store/plan.store";
import { usePlanUIStore } from "@/store/plan.ui.store";

/**
 * 좌측 일정 패널(데스크탑 전용)
 * - Day 리스트(아코디언) + 각 Day의 아이템
 * - 상단 퀵액션: + 장소추가 / 정렬 / 필터 (필요 시 연결)
 *
 * Tailwind 기준으로 lg 이상에서만 노출.
 */
export default function DaySidebar() {
  const navigate = useNavigate();
  const location = useLocation();

  const trip = usePlanStore(selectCurrentTrip);
  const days =
    usePlanStore(
      (s) => selectDaysOfTrip(s, trip?.id),
      shallow
    ) ?? [];

  const currentDayId = usePlanUIStore((s) => s.currentDayId);
  const setCurrentDayId = usePlanUIStore(
    (s) => s.setCurrentDayId
  );

  /** Day가 있는데 currentDayId가 비어 있으면, 첫 번째 Day로 자동 세팅 */
  useEffect(() => {
    if (!currentDayId && days[0]?.id) {
      setCurrentDayId?.(days[0].id);
    }
  }, [currentDayId, days, setCurrentDayId]);

  /** 액션: 장소 추가(검색 오버레이 라우팅) */
  const handleAddPlace = () => {
    const targetDayId = currentDayId || days[0]?.id;
    if (!targetDayId) {
      window.alert(
        "먼저 Day를 하나 추가한 뒤 장소를 등록해 주세요."
      );
      return;
    }
    // 혹시 몰라 다시 한 번 동기화
    setCurrentDayId?.(targetDayId);

    navigate(
      `/plan/search?dayId=${encodeURIComponent(targetDayId)}`,
      {
        state: {
          backgroundLocation: location,
          background: location,
        },
      }
    );
  };

  /** 액션: 정렬/필터(훅업 포인트) */
  const handleSort = () =>
    (window as any)?.toast?.info?.(
      "정렬은 곧 제공됩니다"
    );
  const handleFilter = () =>
    (window as any)?.toast?.info?.(
      "필터는 곧 제공됩니다"
    );

  /** Day 섹션 렌더링 (간단 아코디언) */
  const daySections = useMemo(() => {
    return days
      .slice()
      .sort((a, b) => a.order - b.order)
      .map((d) => {
        const isActive = d.id === currentDayId;
        return (
          <section
            key={d.id}
            className="rounded-xl border border-slate-200 bg-white dark:border-slate-700 dark:bg-slate-900"
            aria-labelledby={`day-${d.id}-label`}
          >
            <header
              id={`day-${d.id}-label`}
              className="flex cursor-pointer items-center justify-between gap-2 px-3 py-2"
            >
              <button
                type="button"
                className="flex min-w-0 items-center gap-3"
                aria-pressed={isActive}
                onClick={() => setCurrentDayId?.(d.id)}
              >
                <span
                  className={[
                    "inline-flex h-6 w-6 items-center justify-center rounded-full text-xs font-semibold",
                    isActive
                      ? "bg-emerald-500 text-white"
                      : "bg-slate-200 text-slate-700 dark:bg-slate-700 dark:text-slate-200",
                  ].join(" ")}
                >
                  {d.order}
                </span>
                <span className="truncate text-sm font-medium text-slate-900 dark:text-slate-100">
                  {new Date(d.dateISO).toLocaleDateString(
                    undefined,
                    {
                      month: "short",
                      day: "numeric",
                      weekday: "short",
                    }
                  )}
                </span>
              </button>

              <div className="flex items-center gap-1">
                <button
                  type="button"
                  className="rounded-md px-2 py-1 text-xs text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                  onClick={handleSort}
                  aria-label="정렬"
                  title="정렬"
                >
                  정렬
                </button>
                <button
                  type="button"
                  className="rounded-md px-2 py-1 text-xs text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
                  onClick={handleFilter}
                  aria-label="필터"
                  title="필터"
                >
                  필터
                </button>
              </div>
            </header>

            {/* 활성 Day만 상세 노출(렌더 최소화) */}
            {isActive && (
              <div className="border-t border-slate-200 px-2 py-2 dark:border-slate-700">
                {/* 
                  1) DayTimeline이 드래그/시간편집 등 로직을 포함할 때 그대로 사용 
                  2) 아니면 TimelineItem 리스트 사용(아래 fallback 블록)
                */}
                <DayTimeline dayId={d.id} />

                {/*
                Fallback(필요 시): TimelineItem 리스트 예시
                */}
              </div>
            )}
          </section>
        );
      });
  }, [days, currentDayId, setCurrentDayId]);

  return (
    <aside
      className="
        hidden lg:flex lg:flex-col
        lg:w-[clamp(320px,28vw,480px)] lg:min-w-[320px] lg:max-w-[480px]
        shrink-0 overflow-hidden border-r border-slate-200 bg-white/90
        backdrop-blur dark:border-slate-800 dark:bg-slate-900/90
      "
      aria-label="여행 일정 패널"
    >
      {/* 상단 퀵 액션(고정) */}
      <div className="sticky top-0 z-10 bg-white/90 backdrop-blur dark:bg-slate-900/90">
        <div className="flex items-center gap-2 border-b border-slate-200 px-3 py-2 dark:border-slate-800">
          <button
            type="button"
            onClick={handleAddPlace}
            className="rounded-md border border-emerald-300 bg-emerald-50 px-3 py-1.5 text-xs font-medium text-emerald-700 hover:bg-emerald-100 dark:border-emerald-700/60 dark:bg-emerald-900/20 dark:text-emerald-300"
            aria-label="장소 추가"
          >
            + 장소 추가
          </button>
          <div className="ml-auto text-[11px] text-slate-500 dark:text-slate-400">
            Day{" "}
            {days.find((d) => d.id === currentDayId)?.order ??
              (days[0]?.order ?? 1)}
          </div>
        </div>
      </div>

      {/* 스크롤 영역: Day 섹션들 */}
      <div className="no-scrollbar flex-1 space-y-3 overflow-y-auto p-3">
        {daySections.length ? (
          daySections
        ) : (
          <div className="rounded-lg border border-dashed border-slate-300 p-4 text-sm text-slate-500 dark:border-slate-700 dark:text-slate-400">
            아직 일정이 없습니다. 위의 <b>+ 장소 추가</b> 버튼으로 일정을
            시작해 보세요.
          </div>
        )}
      </div>
    </aside>
  );
}
