// apps/web/src/components/plan/MapPanel.tsx

import { useEffect, useRef } from "react";
import { useLocation, useNavigate } from "react-router-dom";
import { usePlanUIStore } from "@/store/plan.ui.store";
import { useDayRoute } from "@/hooks/useDayRoute";

type MarkerEntry = {
  id: string;
  marker: google.maps.Marker;
};

export default function MapPanel() {
  const navigate = useNavigate();
  const location = useLocation();

  const hoverSpotId = usePlanUIStore((s) => s.hoverSpotId);

  // ✅ Day 기준 포인트 + Directions 경로
  const {
    dayId: currentDayId,
    points,
    routePath,
  } = useDayRoute();

  const mapRef = useRef<google.maps.Map | null>(null);
  const elRef = useRef<HTMLDivElement | null>(null);
  const markersRef = useRef<MarkerEntry[]>([]);
  const polyRef = useRef<google.maps.Polyline | null>(null);

  // ─────────────────────────────
  // ① Google Map 초기화 (스크립트 늦게 로드돼도 재시도)
  // ─────────────────────────────
  useEffect(() => {
    let cancelled = false;

    const tryInit = () => {
      if (cancelled || mapRef.current || !elRef.current) return;

      const google = (window as any).google as
        | typeof window.google
        | undefined;
      if (!google?.maps) return;

      mapRef.current = new google.maps.Map(elRef.current, {
        center: { lat: 21.028511, lng: 105.804817 }, // 하노이 기준
        zoom: 12,
        disableDefaultUI: true,
        zoomControl: true,
        gestureHandling: "cooperative",
      });
    };

    // 먼저 한 번 시도
    tryInit();

    // 아직 mapRef가 없고, google도 없으면 짧게 polling
    let timer: number | undefined;
    if (!mapRef.current) {
      timer = window.setInterval(() => {
        if (cancelled || mapRef.current) {
          if (timer) window.clearInterval(timer);
          return;
        }
        tryInit();
        if (mapRef.current && timer) {
          window.clearInterval(timer);
        }
      }, 400);
    }

    return () => {
      cancelled = true;
      if (timer) window.clearInterval(timer);
    };
  }, []);

  // hover 스타일 적용 함수
  const applyHover = (hoverId: string | null) => {
    const google = (window as any).google as
      | typeof window.google
      | undefined;
    if (!google) return;

    markersRef.current.forEach(({ id, marker }) => {
      const isActive = hoverId != null && id === hoverId;
      marker.setZIndex(isActive ? 30 : 10);
      marker.setIcon({
        path: google.maps.SymbolPath.CIRCLE,
        scale: isActive ? 9 : 6,
        fillColor: isActive ? "#22c55e" : "#0f172a",
        fillOpacity: 1,
        strokeColor: "#ffffff",
        strokeOpacity: 1,
        strokeWeight: 2,
      });
    });
  };

  // ─────────────────────────────
  // ② Day 변경 / 포인트 or routePath 변경 시 마커 & 폴리라인 갱신
  // ─────────────────────────────
  useEffect(() => {
    const map = mapRef.current;
    const google = (window as any).google as
      | typeof window.google
      | undefined;
    if (!map || !google) return;

    // 기존 마커/폴리라인 제거
    markersRef.current.forEach((entry) => entry.marker.setMap(null));
    markersRef.current = [];
    if (polyRef.current) {
      polyRef.current.setMap(null);
      polyRef.current = null;
    }

    // 새 마커 생성
    for (const p of points) {
      const m = new google.maps.Marker({
        position: { lat: p.lat, lng: p.lng },
        map,
        title: p.title,
      });
      markersRef.current.push({ id: p.id, marker: m });
    }

    // 경로선: Directions 결과가 있으면 그걸 우선 사용
    const pathToDraw =
      routePath && routePath.length >= 2
        ? routePath
        : points.map((p) => ({ lat: p.lat, lng: p.lng }));

    if (pathToDraw.length >= 2) {
      polyRef.current = new google.maps.Polyline({
        path: pathToDraw,
        strokeColor: "#22c55e",
        strokeWeight: 3,
        strokeOpacity: 0.95,
        map,
      });
    }

    // 화면에 맞게 줌/센터 조정
    if (pathToDraw.length) {
      const bounds = new google.maps.LatLngBounds();
      pathToDraw.forEach((p) => bounds.extend({ lat: p.lat, lng: p.lng }));
      map.fitBounds(bounds);
    }

    // 현재 hover 상태 반영
    applyHover(hoverSpotId);
  }, [points, routePath, hoverSpotId]);

  // ─────────────────────────────
  // ③ hoverSpotId 변경 시 마커 강조만 업데이트
  // ─────────────────────────────
  useEffect(() => {
    applyHover(hoverSpotId);
  }, [hoverSpotId]);

  // ─────────────────────────────
  // ④ 상단 “+ 장소 추가” 버튼 → /plan/search?dayId=...
  // ─────────────────────────────
  const openSearch = () => {
    if (!currentDayId) {
      window.alert("먼저 일정을 선택한 뒤 장소를 추가해 주세요.");
      return;
    }
    const searchPath = `/plan/search?dayId=${encodeURIComponent(
      currentDayId
    )}`;
    navigate(searchPath, {
      state: { backgroundLocation: location, background: location },
    });
  };

  // ─────────────────────────────
  // 렌더
  // ─────────────────────────────
  return (
    <div className="relative w-full">
      {/* 툴바 */}
      <div className="pointer-events-none absolute right-3 top-3 z-10">
        <button
          className="pointer-events-auto rounded-md border bg-white/90 px-3 py-1.5 text-sm shadow-sm hover:bg-white dark:border-gray-700 dark:bg-gray-900/90 dark:hover:bg-gray-900"
          onClick={openSearch}
        >
          + 장소 추가
        </button>
      </div>

      {/* ✅ 고정 높이: 지도 영역 */}
      <div
        ref={elRef}
        className="h-[520px] w-full rounded-md border bg-gray-100 dark:border-gray-800 dark:bg-gray-900"
      />

      {!points.length && (
        <div className="pointer-events-none absolute right-3 bottom-3 rounded-md border bg-white/90 px-3 py-1.5 text-xs text-gray-700 dark:border-gray-700 dark:bg-gray-900/90 dark:text-gray-200">
          “+ 장소 추가”를 눌러 오늘 일정에 스팟을 담아보세요.
        </div>
      )}
    </div>
  );
}
