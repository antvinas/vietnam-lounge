// apps/web/src/components/plan/PlanSummaryBar.tsx

import React from "react";
import {
  usePlanStore,
  selectCurrentTrip,
  selectDaysOfTrip,
  selectItemsOfDay,
  selectConflictsOfDay,
} from "@/store/plan.store";
import { usePlanUIStore } from "@/store/plan.ui.store";
import { shallow } from "zustand/shallow";
import { buildGoogleDirectionsUrl } from "@/lib/googleDirections";

function Chip({
  label,
  value,
  kind = "neutral",
  icon,
}: {
  label: string;
  value: string;
  kind?: "neutral" | "warn" | "danger";
  icon?: string;
}) {
  const cls =
    kind === "danger"
      ? "inline-flex items-center gap-1 rounded-md border border-red-300 bg-red-50 px-2 py-1 text-xs font-medium text-red-700 dark:border-red-700/40 dark:bg-red-900/30 dark:text-red-200"
      : kind === "warn"
      ? "inline-flex items-center gap-1 rounded-md border border-amber-300 bg-amber-50 px-2 py-1 text-xs font-medium text-amber-800 dark:border-amber-700/40 dark:bg-amber-900/30 dark:text-amber-200"
      : "inline-flex items-center gap-1 rounded-md border border-gray-300 bg-gray-50 px-2 py-1 text-xs font-medium text-gray-700 dark:border-gray-700/40 dark:bg-gray-800/60 dark:text-gray-200";
  return (
    <span className={cls}>
      {icon ? (
        <span aria-hidden className="opacity-80">
          {icon}
        </span>
      ) : null}
      <span>{label}</span>
      <span className="tabular-nums">{value}</span>
    </span>
  );
}

export default function PlanSummaryBar() {
  const trip = usePlanStore(selectCurrentTrip);
  const days =
    usePlanStore((s) => selectDaysOfTrip(s, trip?.id)) || [];
  const currentDayId =
    usePlanUIStore((s) => s.currentDayId) ?? days[0]?.id ?? null;

  const { currency, budgetLeft } = usePlanStore(
    (s) => {
      const id = trip?.id ?? s.currentTripId ?? "";
      const spent = Object.values(s.items)
        .filter((it) => it.tripId === id)
        .reduce((a, it) => a + (it.cost ?? 0), 0);
      const total = s.trips[id]?.budgetTotal ?? 0;
      return {
        currency: s.trips[id]?.currency ?? "VND",
        budgetLeft: Math.max(0, total - spent),
      };
    },
    shallow
  );

  const {
    dayItems,
    conflictCount,
    travelMinutesOfDay,
    isCalculating,
    places,
  } = usePlanStore(
    (s) => {
      if (!currentDayId)
        return {
          dayItems: [] as any[],
          conflictCount: 0,
          travelMinutesOfDay: 0,
          isCalculating: false,
          places: s.places,
        };
      const items = selectItemsOfDay(s, currentDayId);
      const conflicts = selectConflictsOfDay(s, currentDayId);
      const ids = new Set(items.map((i) => i.id));
      let totalSec = 0;
      let missing = false;
      for (const ln of Object.values(s.links)) {
        if (!(ids.has(ln.fromItemId) && ids.has(ln.toItemId))) continue;
        if (ln.durationSec == null) missing = true;
        totalSec += ln.durationSec ?? 0;
      }
      return {
        dayItems: items,
        conflictCount: conflicts.length,
        travelMinutesOfDay: Math.round(totalSec / 60),
        isCalculating: missing,
        places: s.places,
      };
    },
    shallow
  );

  const duplicateTripAsUser = usePlanStore(
    (s) => s.duplicateTripAsUser
  );

  const handleConvertSample = () => {
    if (!trip?.id) return;
    const newId = duplicateTripAsUser(trip.id);
    if (!newId) return;
    // duplicateTripAsUser 내부에서 currentTripId / currentDayId / 토스트까지 처리
  };

  const isSample = !!trip?.isSample;

  // ─────────────────────────────
  // Day 전체 Google Maps 길찾기 URL 계산
  // ─────────────────────────────
  const canOpenDirections = React.useMemo(() => {
    if (!currentDayId || dayItems.length < 2) return false;
    const first = dayItems[0];
    const last = dayItems[dayItems.length - 1];
    if (!first.placeId || !last.placeId) return false;
    const p1 = (places as any)[first.placeId];
    const p2 = (places as any)[last.placeId];
    if (!p1 || !p2) return false;
    if (
      typeof p1.lat !== "number" ||
      typeof p1.lng !== "number" ||
      typeof p2.lat !== "number" ||
      typeof p2.lng !== "number"
    )
      return false;
    return true;
  }, [currentDayId, dayItems, places]);

  const handleOpenDayDirections = () => {
    if (!canOpenDirections) return;
    const first = dayItems[0];
    const last = dayItems[dayItems.length - 1];
    const p1 = (places as any)[first.placeId];
    const p2 = (places as any)[last.placeId];

    const url = buildGoogleDirectionsUrl({
      origin: { lat: p1.lat, lng: p1.lng },
      destination: { lat: p2.lat, lng: p2.lng },
      // 필요하면 waypoints: 중간 장소들 추가 가능
      // waypoints: dayItems.slice(1, -1).map((it) => {
      //   const p = (places as any)[it.placeId];
      //   return { lat: p.lat, lng: p.lng };
      // }),
      travelMode: "driving",
    });

    window.open(url, "_blank", "noopener,noreferrer");
  };

  return (
    <div
      id="plan-summary"
      className="sticky top-0 z-30 w-full border-b border-gray-200/70 bg-white/85 backdrop-blur dark:border-gray-800/70 dark:bg-gray-900/80"
      role="region"
      aria-label="플랜 요약"
    >
      <div className="mx-auto flex max-w-screen-2xl items-center gap-3 px-3 py-2">
        <div className="mr-2 shrink-0 text-sm font-semibold text-gray-700 dark:text-gray-200">
          플랜 요약
        </div>

        {isSample && (
          <div className="mr-3 flex items-center gap-2">
            <span className="inline-flex items-center gap-1 rounded-full border border-emerald-300 bg-emerald-50 px-2 py-0.5 text-[11px] font-medium text-emerald-700 dark:border-emerald-600/50 dark:bg-emerald-900/40 dark:text-emerald-200">
              <span aria-hidden>⭐</span>
              <span>샘플 일정</span>
            </span>
            <button
              type="button"
              onClick={handleConvertSample}
              className="rounded-md border border-emerald-400 bg-emerald-50 px-2.5 py-1 text-[11px] font-medium text-emerald-800 hover:bg-emerald-100 dark:border-emerald-600/70 dark:bg-emerald-900/40 dark:text-emerald-100 dark:hover:bg-emerald-900"
            >
              내 일정으로 복사
            </button>
          </div>
        )}

        <div
          className="flex flex-1 flex-wrap items-center gap-2"
          role="status"
          aria-live="polite"
        >
          {/* 예산: 남은 예산 기준으로 표시 */}
          <Chip
            icon="₫"
            label="예산 잔액"
            value={`${budgetLeft.toLocaleString()} ${currency}`}
          />
          {/* 이동 시간 */}
          {isCalculating ? (
            <Chip
              icon="🕒"
              label="이동시간"
              value="계산 중…"
              kind="warn"
            />
          ) : (
            <Chip
              icon="🕒"
              label="이동시간"
              value={`${travelMinutesOfDay}분`}
            />
          )}
          {/* 겹치는 일정 */}
          <Chip
            icon="⚠️"
            label="겹치는 일정"
            value={`${conflictCount}건`}
            kind={conflictCount > 0 ? "warn" : "neutral"}
          />

          {/* Day 전체 Google Maps 길찾기 버튼 */}
          {canOpenDirections && (
            <button
              type="button"
              onClick={handleOpenDayDirections}
              className="ml-auto inline-flex items-center gap-1 rounded-md border border-blue-300 bg-blue-50 px-2.5 py-1 text-[11px] font-medium text-blue-700 hover:bg-blue-100 dark:border-blue-500/60 dark:bg-blue-900/40 dark:text-blue-100 dark:hover:bg-blue-900"
            >
              <span aria-hidden>🗺</span>
              <span>오늘 일정 길찾기 (Google)</span>
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
