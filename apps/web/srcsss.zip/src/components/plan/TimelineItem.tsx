import React from "react";

/** 최소 아이템 스키마 (프레젠테이션용) */
export type TimelineItemData = {
  id: string;
  title: string;
  type?: "spot" | "food" | "spa" | "activity" | "custom" | string;
  placeName?: string;
  timeStartMin?: number; // 0~1440
  timeEndMin?: number; // 0~1440
  cost?: number;
  icon?: React.ReactNode; // 외부에서 아이콘 주입 가능
};

export type TimelineItemProps = {
  item: TimelineItemData;

  /** 선택/비활성 표시 */
  selected?: boolean;
  disabled?: boolean;

  /** 상호작용 콜백(필요한 것만 연결해서 사용) */
  onClick?: (id: string) => void;
  onRemove?: (id: string) => void;
  onTimeEdit?: (id: string) => void;
  onReorderUp?: (id: string) => void;
  onReorderDown?: (id: string) => void;
  onHoverChange?: (id: string | null) => void;

  /** 외부 DnD 라이브러리와 결합할 때 전달 */
  draggableProps?: React.HTMLAttributes<HTMLDivElement>;
  dragHandleProps?: React.ButtonHTMLAttributes<HTMLButtonElement>;

  /** 라벨 커스터마이즈 (i18n 연결 시 사용) */
  labels?: {
    timeUnset?: string; // 기본: "시간 미정"
    editTime?: string; // 기본: "시간 편집"
    remove?: string; // 기본: "삭제"
    moveUp?: string; // 기본: "위로"
    moveDown?: string; // 기본: "아래로"
  };

  /** 테스트/추가 스타일 */
  className?: string;
};

/* ──────────────────────────── 유틸 ──────────────────────────── */

function cn(...xs: Array<string | false | null | undefined>) {
  return xs.filter(Boolean).join(" ");
}

export function minutesToHHmm(m?: number): string {
  if (m == null || Number.isNaN(m)) return "--:--";
  const mm = Math.max(0, Math.min(24 * 60, Math.round(m)));
  const h = Math.floor(mm / 60);
  const min = mm % 60;
  return `${`${h}`.padStart(2, "0")}:${`${min}`.padStart(2, "0")}`;
}

function timeRangeLabel(st?: number, en?: number, fallback = "시간 미정") {
  if (st == null || en == null) return fallback;
  return `${minutesToHHmm(st)} – ${minutesToHHmm(en)}`;
}

const DEFAULT_LABELS: Required<NonNullable<TimelineItemProps["labels"]>> = {
  timeUnset: "시간 미정",
  editTime: "시간 편집",
  remove: "삭제",
  moveUp: "위로",
  moveDown: "아래로",
};

function defaultIconForType(type?: string) {
  switch (type) {
    case "food":
      return "🍽";
    case "activity":
      return "🧭";
    case "spa":
      return "💆";
    case "spot":
      return "📍";
    default:
      return "▪️";
  }
}

function typeLabel(type?: string) {
  switch (type) {
    case "food":
      return "식사";
    case "activity":
      return "액티비티";
    case "spa":
      return "휴식";
    case "spot":
      return "관광";
    default:
      return "기타";
  }
}

export default function TimelineItem({
  item,
  selected,
  disabled,
  onClick,
  onRemove,
  onTimeEdit,
  onReorderUp,
  onReorderDown,
  onHoverChange,
  draggableProps,
  dragHandleProps,
  labels: L,
  className,
}: TimelineItemProps) {
  const labels = { ...DEFAULT_LABELS, ...(L || {}) };
  const effectiveType = (item.type as string) || "custom";

  const typeClass =
    {
      food: "tl-type-food",
      spa: "tl-type-spa",
      activity: "tl-type-activity",
      spot: "tl-type-spot",
      custom: "tl-type-custom",
    }[effectiveType] ?? "tl-type-custom";

  const badgeClass =
    {
      food: "tl-badge tl-badge-food",
      spa: "tl-badge tl-badge-spa",
      activity: "tl-badge tl-badge-activity",
      spot: "tl-badge tl-badge-spot",
      custom: "tl-badge tl-badge-custom",
    }[effectiveType] ?? "tl-badge tl-badge-custom";

  const resolvedIcon = item.icon ?? defaultIconForType(effectiveType);

  const handleKey = (e: React.KeyboardEvent<HTMLDivElement>) => {
    if (disabled) return;
    // Enter/Space: 선택
    if ((e.key === "Enter" || e.key === " ") && onClick) {
      e.preventDefault();
      onClick(item.id);
    }
    // Delete/Backspace: 삭제
    if ((e.key === "Delete" || e.key === "Backspace") && onRemove) {
      e.preventDefault();
      onRemove(item.id);
    }
    // Ctrl/Cmd + ↑/↓ : 재정렬
    const mod = e.ctrlKey || e.metaKey;
    if (mod && e.key === "ArrowUp" && onReorderUp) {
      e.preventDefault();
      onReorderUp(item.id);
    }
    if (mod && e.key === "ArrowDown" && onReorderDown) {
      e.preventDefault();
      onReorderDown(item.id);
    }
  };

  const rangeText = timeRangeLabel(
    item.timeStartMin,
    item.timeEndMin,
    labels.timeUnset
  );

  // 3번째 줄(서브텍스트)에 들어갈 내용
  const subtitleParts: string[] = [];
  if (item.placeName) subtitleParts.push(item.placeName);
  if (item.cost != null)
    subtitleParts.push(`${item.cost.toLocaleString()} VND`);
  const subtitle = subtitleParts.join(" · ");

  return (
    <div
      role="listitem"
      aria-selected={selected || false}
      tabIndex={0}
      onKeyDown={handleKey}
      onMouseEnter={() => onHoverChange?.(item.id)}
      onMouseLeave={() => onHoverChange?.(null)}
      className={cn(
        "group relative grid grid-cols-[1fr_auto] items-stretch gap-3 rounded-xl border",
        "border-slate-200 bg-white px-3 py-2.5 shadow-sm transition-colors",
        "hover:bg-slate-50 focus:outline-none focus-visible:ring-2 focus-visible:ring-emerald-500",
        "dark:border-slate-700 dark:bg-slate-900 dark:hover:bg-slate-800",
        selected && "ring-2 ring-emerald-500",
        disabled && "opacity-60 pointer-events-none",
        "tl-item",
        typeClass,
        className
      )}
      {...draggableProps}
      aria-describedby={subtitle ? `tl-${item.id}-desc` : undefined}
      onClick={(e) => {
        // 우측 액션 클릭 시 row onClick 막기
        if ((e.target as HTMLElement)?.closest?.("[data-ti-action]")) return;
        onClick?.(item.id);
      }}
    >
      {/* 메인 내용 컬럼 (3줄 구조) */}
      <div className="min-w-0 space-y-0.5 py-0.5">
        {/* 1줄: 시간 범위 + 카테고리 뱃지 */}
        <div className="flex items-center gap-2 text-[11px] text-slate-500 dark:text-slate-400">
          <span className="font-mono tabular-nums">{rangeText}</span>
          <span className={cn(badgeClass, "shrink-0")}>
            {typeLabel(effectiveType)}
          </span>
        </div>

        {/* 2줄: 아이콘 + 장소 이름(굵게) */}
        <div className="flex items-center gap-2">
          <span
            aria-hidden
            className="inline-flex h-6 w-6 items-center justify-center rounded-full bg-slate-100 text-sm text-slate-600 dark:bg-slate-800 dark:text-slate-300"
          >
            {resolvedIcon}
          </span>
          <div className="truncate text-sm font-semibold text-slate-900 dark:text-slate-100">
            {item.title}
          </div>
        </div>

        {/* 3줄: 가격/장소명 등 서브 텍스트 */}
        {subtitle && (
          <div
            id={`tl-${item.id}-desc`}
            className="truncate text-[11px] text-slate-500 dark:text-slate-400"
          >
            {subtitle}
          </div>
        )}
      </div>

      {/* 우측 액션들 */}
      <div className="flex items-center gap-1">
        {/* 드래그 핸들 (나중에 DnD 붙일 때 사용) */}
        <button
          type="button"
          title="Drag to reorder"
          aria-label="Drag to reorder"
          data-ti-action
          className={cn(
            "hidden cursor-grab rounded-md px-2 py-1 text-slate-500 hover:bg-slate-100 active:cursor-grabbing",
            "group-hover:inline-flex dark:hover:bg-slate-800"
          )}
          {...dragHandleProps}
        >
          ⋮⋮
        </button>

        {/* 시간 편집 */}
        {onTimeEdit && (
          <button
            type="button"
            data-ti-action
            className="rounded-md px-2 py-1 text-[11px] text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
            onClick={() => onTimeEdit(item.id)}
          >
            {labels.editTime}
          </button>
        )}

        {/* 위/아래 이동 (추후 연동용) */}
        {onReorderUp && (
          <button
            type="button"
            data-ti-action
            aria-label={labels.moveUp}
            title={labels.moveUp}
            className="rounded-md px-2 py-1 text-[11px] text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
            onClick={() => onReorderUp(item.id)}
          >
            ↑
          </button>
        )}
        {onReorderDown && (
          <button
            type="button"
            data-ti-action
            aria-label={labels.moveDown}
            title={labels.moveDown}
            className="rounded-md px-2 py-1 text-[11px] text-slate-600 hover:bg-slate-100 dark:text-slate-300 dark:hover:bg-slate-800"
            onClick={() => onReorderDown(item.id)}
          >
            ↓
          </button>
        )}

        {/* 삭제 */}
        {onRemove && (
          <button
            type="button"
            data-ti-action
            className="rounded-md px-2 py-1 text-[11px] text-rose-600 hover:bg-rose-50 dark:text-rose-400 dark:hover:bg-rose-900/30"
            onClick={() => onRemove(item.id)}
          >
            {labels.remove}
          </button>
        )}
      </div>
    </div>
  );
}
