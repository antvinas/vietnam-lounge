/**
 * useFocusTrap
 * - 모달/오버레이 내부로 Tab 포커스를 가둔다.
 * - 초기 포커스를 지정하고, 닫을 때 이전 포커스로 복귀한다.
 * - ESC 키로 닫기 콜백을 호출한다.
 * - (New) 다중 모달을 위한 "트랩 스택" 지원: top만 이벤트를 소비.
 *
 * 적용 대상은 role="dialog" 또는 role="alertdialog" 컨테이너가 적절하다.
 */
import { useEffect, useRef } from "react";

// ── 모듈 전역 트랩 스택
type TrapEntry = {
  container: HTMLElement;
  initial?: HTMLElement | null;
  prevFocus: HTMLElement | null;
  onEscape?: () => void;
  returnFocus: boolean;
};
const trapStack: TrapEntry[] = [];

export type FocusTrapOptions = {
  /** 트랩할 컨테이너 ref (role="dialog" 권장) */
  containerRef: React.RefObject<HTMLElement>;
  /** 열릴 때 포커스를 둘 요소 ref. 없으면 컨테이너 내 첫 포커스 가능 요소 */
  initialFocusRef?: React.RefObject<HTMLElement>;
  /** 닫힐 때 기존 포커스로 복귀 여부. 기본값 true */
  returnFocus?: boolean;
  /** 활성화 여부. 기본값 true */
  enabled?: boolean;
  /** ESC 누를 때 호출 */
  onEscape?: () => void;
};

const FOCUSABLE_SELECTOR = [
  "a[href]",
  "button:not([disabled])",
  "input:not([type=hidden]):not([disabled])",
  "select:not([disabled])",
  "textarea:not([disabled])",
  '[tabindex]:not([tabindex="-1"])',
  '[contenteditable="true"]',
  "summary",
].join(",");

function getFocusable(root: HTMLElement | null): HTMLElement[] {
  if (!root) return [];
  const nodes = Array.from(root.querySelectorAll<HTMLElement>(FOCUSABLE_SELECTOR));
  // 표시되지 않는 요소 제외
  return nodes.filter((el) => el.offsetParent !== null || el === document.activeElement);
}

export function useFocusTrap(options: FocusTrapOptions) {
  const { containerRef, initialFocusRef, onEscape } = options;
  const enabled = options.enabled ?? true;
  const returnFocus = options.returnFocus ?? true;

  const entryRef = useRef<TrapEntry | null>(null);

  // 초기 포커스 및 스택 push
  useEffect(() => {
    if (!enabled) return;

    const container = containerRef.current;
    if (!container) return;

    const prev = (document.activeElement as HTMLElement) ?? null;
    const init =
      initialFocusRef?.current || getFocusable(container)[0] || container;

    container.setAttribute("aria-modal", "true"); // Safari 대응에 한계가 있어도 명시 권장
    // APG: 초기 포커스 이동
    const raf = requestAnimationFrame(() => init.focus());

    const entry: TrapEntry = {
      container,
      initial: init,
      prevFocus: prev,
      onEscape,
      returnFocus,
    };
    trapStack.push(entry);
    entryRef.current = entry;

    return () => {
      cancelAnimationFrame(raf);
    };
  }, [enabled, containerRef, initialFocusRef, onEscape, returnFocus]);

  // Tab 순환 및 ESC 처리 (top 트랩만 활성)
  useEffect(() => {
    if (!enabled) return;

    const onKey = (e: KeyboardEvent) => {
      const top = trapStack[trapStack.length - 1];
      if (!top || top !== entryRef.current) return; // top 아니면 무시

      const container = top.container;
      if (!container) return;

      if (e.key === "Escape") {
        if (top.onEscape) {
          e.stopPropagation();
          e.preventDefault();
          top.onEscape();
        }
        return;
      }

      if (e.key !== "Tab") return;

      const focusables = getFocusable(container);
      if (focusables.length === 0) {
        e.preventDefault();
        container.focus();
        return;
      }

      const first = focusables[0];
      const last = focusables[focusables.length - 1];
      const active = document.activeElement as HTMLElement | null;

      if (e.shiftKey) {
        if (active === first || !container.contains(active)) {
          e.preventDefault();
          last.focus();
        }
      } else {
        if (active === last) {
          e.preventDefault();
          first.focus();
        }
      }
    };

    document.addEventListener("keydown", onKey, true);
    return () => document.removeEventListener("keydown", onKey, true);
  }, [enabled]);

  // unmount 시 스택 pop 및 포커스 복원
  useEffect(() => {
    return () => {
      const idx = trapStack.lastIndexOf(entryRef.current as TrapEntry);
      if (idx !== -1) trapStack.splice(idx, 1);

      const entry = entryRef.current;
      if (!entry) return;

      if (entry.returnFocus && entry.prevFocus && typeof entry.prevFocus.focus === "function") {
        setTimeout(() => entry.prevFocus!.focus(), 0);
      }
    };
  }, []);
}

export default useFocusTrap;
