// 정규화 스토어 타입 기반 PDF 출력
import type { Trip, Day, Item, Link } from "@/store/plan.store";

const style = `
  body { font-family: ui-sans-serif, system-ui, -apple-system, Segoe UI, Roboto, "Noto Sans", "Noto Sans KR", "Malgun Gothic", "Apple SD Gothic Neo", "Nanum Gothic", Helvetica, Arial; color:#0f172a; }
  h1 { font-size: 20px; margin: 16px 0; }
  h2 { font-size: 16px; margin: 14px 0 8px; }
  .sec { border:1px solid #e2e8f0; border-radius:12px; padding:12px; margin-bottom:12px; }
  .row { display:flex; justify-content:space-between; padding:6px 0; border-bottom:1px solid #f1f5f9; }
  .row:last-child { border-bottom:none; }
  .meta { color:#64748b; font-size:12px; }
  .sum { display:flex; gap:12px; flex-wrap:wrap; margin-bottom:8px; }
  .chip { border:1px solid #e2e8f0; border-radius:999px; padding:4px 10px; font-size:12px; }
`;

function escapeHtml(s: string) {
  return s
    .replaceAll("&", "&amp;")
    .replaceAll("<", "&lt;")
    .replaceAll(">", "&gt;")
    .replaceAll('"', "&quot;")
    .replaceAll("'", "&#039;");
}

function fmtMoney(v: number, currency: string) {
  return new Intl.NumberFormat(
    currency === "KRW" ? "ko-KR" : currency === "USD" ? "en-US" : "vi-VN",
    { style: "currency", currency, maximumFractionDigits: 0 }
  ).format(v);
}

/** 정규화 스토어 스키마 입력 → 인쇄 보기 */
export function openPlanPrintFromNormalized(trip: Trip, days: Day[], items: Item[], links: Link[]) {
  const w = window.open("", "_blank", "noopener,noreferrer,width=900,height=900");
  if (!w) return;

  // day 정렬
  const dayList = [...days].sort((a, b) => a.order - b.order);
  const itemsByDay = new Map<string, Item[]>();
  dayList.forEach((d) => {
    itemsByDay.set(
      d.id,
      items
        .filter((it) => it.dayId === d.id)
        .sort((a, b) => (a.timeStartMin ?? 0) - (b.timeStartMin ?? 0))
    );
  });

  // 링크를 day 기준으로 합산
  const durationByDaySec = new Map<string, number>();
  dayList.forEach((d) => durationByDaySec.set(d.id, 0));
  for (const ln of links) {
    const from = items.find((i) => i.id === ln.fromItemId);
    const to = items.find((i) => i.id === ln.toItemId);
    if (!from || !to) continue;
    if (from.dayId === to.dayId && durationByDaySec.has(from.dayId)) {
      durationByDaySec.set(from.dayId, (durationByDaySec.get(from.dayId) || 0) + (ln.durationSec ?? 0));
    }
  }

  // 전체 합계
  const totalCost = items.reduce((s, b) => s + (b.cost || 0), 0);
  const totalMoveMin = Math.round(
    Array.from(durationByDaySec.values()).reduce((a, b) => a + b, 0) / 60
  );

  const daySections = dayList
    .map((d) => {
      const its = itemsByDay.get(d.id) || [];
      const rows = its
        .map((b) => {
          const start =
            typeof b.timeStartMin === "number"
              ? `${String((b.timeStartMin / 60) | 0).padStart(2, "0")}:${String(b.timeStartMin % 60).padStart(2, "0")}`
              : "-";
          const end =
            typeof b.timeEndMin === "number"
              ? `${String((b.timeEndMin / 60) | 0).padStart(2, "0")}:${String(b.timeEndMin % 60).padStart(2, "0")}`
              : "-";
          const cost = typeof b.cost === "number" ? fmtMoney(b.cost, trip.currency) : "";
          return `
            <div class="row">
              <div>
                <div><strong>${escapeHtml(b.title || "(제목 없음)")}</strong></div>
                <div class="meta">${String(b.type || "item").toUpperCase()} · ${start} ~ ${end}</div>
              </div>
              <div>${cost}</div>
            </div>`;
        })
        .join("");

      const dayCost = its.reduce((s, x) => s + (x.cost || 0), 0);
      const dayMoveMin = Math.round((durationByDaySec.get(d.id) || 0) / 60);

      return `
        <section class="sec">
          <h2>Day ${d.order} · ${escapeHtml(d.dateISO)}</h2>
          <div class="sum">
            <span class="chip">이동 ${dayMoveMin}분</span>
            <span class="chip">비용 ${fmtMoney(dayCost, trip.currency)}</span>
          </div>
          ${rows || `<div class="meta">항목 없음</div>`}
        </section>`;
    })
    .join("");

  const html = `
    <!doctype html>
    <html>
      <head>
        <meta charset="utf-8" />
        <title>${escapeHtml("여행 플랜")}</title>
        <style>${style}</style>
      </head>
      <body>
        <h1>${escapeHtml("여행 플랜")}</h1>
        <div class="sec">
          <div class="sum">
            <span class="chip">총 이동 ${totalMoveMin}분</span>
            <span class="chip">총 비용 ${fmtMoney(totalCost, trip.currency)}</span>
            <span class="chip">통화 ${escapeHtml(trip.currency)}</span>
          </div>
        </div>
        ${daySections}
        <script>window.onload = () => setTimeout(() => window.print(), 200);</script>
      </body>
    </html>
  `;

  w.document.open();
  w.document.write(html);
  w.document.close();
}

/** (이전 호환) 제목과 임의 블록 배열을 받던 구버전 API */
export function openPlanPrintView(_title: string, _blocks: any[]) {
  console.warn("openPlanPrintView는 폐기 예정입니다. openPlanPrintFromNormalized를 사용하세요.");
  const win = window.open("", "_blank");
  if (win) { win.document.write("<p>Deprecated API. Use openPlanPrintFromNormalized.</p>"); win.document.close(); }
}
