// pages/Plan/index.tsx
import React, { useEffect, useMemo } from "react";
import { useLocation, useNavigate, Outlet } from "react-router-dom";

import { usePlanStore } from "@/store/plan.store";
import { usePlanUIStore } from "@/store/plan.ui.store";

import DaySidebar from "@/components/plan/DaySidebar";
import PlanSummaryBar from "@/components/plan/PlanSummaryBar";
import MapPanel from "@/components/plan/MapPanel";
import MobileSheet from "@/components/plan/MobileSheet";
import PlanEmptyState from "@/components/plan/PlanEmptyState";

import { openPlanPrintFromNormalized } from "@/utils/export/planPdf";
import { t, getDefaultLocale } from "@/components/plan/strings";

import "@/styles/plan.layout.css";

/** yyyy-mm-dd */
function todayISODate() {
  return new Date().toISOString().slice(0, 10);
}

export default function PlanPage() {
  const locale = getDefaultLocale();

  const navigate = useNavigate();
  const location = useLocation();

  const currentTripId = usePlanStore((s) => s.currentTripId);
  const hasExistingTrip = usePlanStore((s) =>
    Object.values(s.trips).some((t) => !t.isSample)
  );

  const setCurrentDayId = usePlanUIStore((s) => s.setCurrentDayId);

  const isPlanSheetOpen = usePlanUIStore((s) => s.isPlanSheetOpen);
  const setPlanSheetOpen = usePlanUIStore((s) => s.setPlanSheetOpen);

  // 현재 Trip / Day / Item / Link → PDF 내보내기에 사용
  const currentTrip = usePlanStore((s: any) =>
    currentTripId ? s.trips[currentTripId] : undefined
  );

  const daysOfTrip = usePlanStore((s: any) =>
    currentTripId
      ? Object.values(s.days).filter((d: any) => d.tripId === currentTripId)
      : []
  );

  const itemsOfTrip = usePlanStore((s: any) =>
    currentTripId
      ? Object.values(s.items).filter(
          (it: any) => it.tripId === currentTripId
        )
      : []
  );

  const linksOfTrip = usePlanStore((s: any) =>
    currentTripId && s.links
      ? Object.values(s.links).filter(
          (ln: any) => ln.tripId === currentTripId
        )
      : []
  );

  const handleExportPdf = () => {
    if (!currentTrip) {
      window.alert(t(locale, "planPage", "selectTripFirst") as string);
      return;
    }

    try {
      openPlanPrintFromNormalized(
        currentTrip as any,
        daysOfTrip as any,
        itemsOfTrip as any,
        linksOfTrip as any
      );
    } catch (e) {
      console.error(e);
      window.alert(t(locale, "planPage", "pdfError") as string);
    }
  };

  // 예시 모달 열기
  const openSampleChooser = () => {
    navigate("/plan/sample", {
      state: { backgroundLocation: location, background: location },
    });
  };

  // 간편 새 일정 만들기(위저드 없이 바로 생성)
  const createQuickTrip = () => {
    const st = usePlanStore.getState();
    const id = st.createTrip({
      startDateISO: todayISODate(),
      nights: 2,
      currency: "VND",
      budgetTotal: 0,
      transportDefault: "car",
    });

    // 첫 날을 UI에 설정
    const firstDay = Object.values(st.days)
      .filter((d: any) => d.tripId === id)
      .sort((a: any, b: any) => a.order - b.order)[0];

    if (firstDay) setCurrentDayId(firstDay.id);

    // 새 일정 만든 뒤에도 /plan 으로 확실히 보내기
    navigate("/plan");
  };

  // 기존 플랜(샘플이 아닌 일정) 중 가장 최근 것 이어서 보기
  const openLastSavedTrip = () => {
    const st = usePlanStore.getState();

    const trips = Object.values(st.trips).filter((t: any) => !t.isSample);
    if (trips.length === 0) {
      window.alert(t(locale, "planPage", "noSavedTrip") as string);
      return;
    }

    const sorted = [...trips].sort((a: any, b: any) => {
      const ta = (a as any).updatedAt || (a as any).createdAt;
      const tb = (b as any).updatedAt || (b as any).createdAt;
      if (ta === tb) return 0;
      return ta < tb ? 1 : -1; // 최신 순
    });

    const target: any = sorted[0];

    // 현재 선택된 trip 변경
    usePlanStore.setState({ currentTripId: target.id });

    // 해당 trip의 첫 번째 Day를 UI에 설정
    const firstDay = Object.values(st.days)
      .filter((d: any) => d.tripId === target.id)
      .sort((a: any, b: any) => a.order - b.order)[0];

    if (firstDay) {
      setCurrentDayId(firstDay.id);
    }
  };

  // 모바일에서 플랜이 있을 때 한 번 자동으로 시트 열기
  useEffect(() => {
    if (typeof window === "undefined") return;
    const isMobile = window.matchMedia("(max-width: 1024px)").matches;
    if (isMobile && currentTripId && !isPlanSheetOpen) {
      setPlanSheetOpen(true);
    }
  }, [currentTripId, isPlanSheetOpen, setPlanSheetOpen]);

  // 요약바 푸터 버튼(모바일 시트 하단)
  const mobileFooter = useMemo(
    () => (
      <div className="flex items-center justify-between gap-2">
        <button
          type="button"
          className="rounded-md border px-3 py-2 text-sm dark:border-gray-700"
          onClick={openSampleChooser}
        >
          {t(locale, "planPage", "mobileSampleButton")}
        </button>
        <button
          type="button"
          className="rounded-md bg-emerald-500 px-3 py-2 text-sm text-white"
          onClick={() =>
            navigate("/plan/search", {
              state: { backgroundLocation: location, background: location },
            })
          }
        >
          {t(locale, "planPage", "mobileAddPlaceButton")}
        </button>
      </div>
    ),
    [location, navigate, locale]
  );

  // ──────────────────────────────────────────────────────────────
  // 렌더
  // ──────────────────────────────────────────────────────────────
  const hasTrip = !!currentTripId;

  return (
    <div className="plan-root">
      {hasTrip && (
        <>
          <PlanSummaryBar />
          {/* 상단 우측: PDF 내보내기 버튼 */}
          <div className="flex justify-end px-4 pb-2">
            <button
              type="button"
              onClick={handleExportPdf}
              className="rounded-md border px-3 py-1.5 text-xs text-gray-700 hover:bg-gray-50 dark:border-gray-700 dark:text-gray-200 dark:hover:bg-gray-800"
            >
              {t(locale, "planPage", "pdfButton")}
            </button>
          </div>
        </>
      )}

      {hasTrip ? (
        <div className="plan-grid">
          {/* 좌측: 일정 패널(데스크탑 전용) */}
          <aside className="plan-left desktop-only">
            <DaySidebar />
          </aside>

          {/* 우측: 지도 */}
          <main className="plan-right">
            <MapPanel />
          </main>
        </div>
      ) : (
        <div className="mx-auto my-12 max-w-xl">
          <PlanEmptyState
            hasExistingTrip={hasExistingTrip}
            onCreateNew={createQuickTrip}
            onOpenSample={openSampleChooser}
            onOpenExisting={openLastSavedTrip}
            locale={locale}
          />
        </div>
      )}

      {/* 모바일: 일정 시트 (플랜이 있을 때만) */}
      {hasTrip && (
        <MobileSheet
          open={isPlanSheetOpen}
          onClose={() => setPlanSheetOpen(false)}
          title={t(locale, "planPage", "mobileTodayTitle") as string}
          initialSnap="large"
          footer={mobileFooter}
        >
          <div className="p-2">
            <DaySidebar />
          </div>
        </MobileSheet>
      )}

      {/* /plan/search, /plan/sample 오버레이 라우트 출력 */}
      <Outlet />
    </div>
  );
}
