import type { PlanTemplate } from "@/types/plan.template";

/** 좌표는 대략치. 사용 중 보정 가능 */
const tpl: PlanTemplate = {
  meta: {
    id: "phuquoc-3n4d",
    city: "Phu Quoc",
    title: "푸꾸옥 3박4일 샘플",
    nights: 3,
    defaultMode: "car",
    currency: "VND",
    plannedBudgetVnd: 9000000, // 대략: 숙소/교통/입장권(1인 기준 예시)
    summary: "북부 사파리·빈원더 + 남부 케이블카·섬투어 중심",
  },
  base: {
    name: "Grand World Phu Quoc",
    location: { lat: 10.3648, lng: 103.8552 },
  },
  days: [
    {
      label: "도착/체크인",
      items: [
        { kind: "activity", name: "공항 도착", location: { lat: 10.227, lng: 103.967 }, timeStartMin: 720, timeEndMin: 780 },
        { kind: "activity", name: "호텔 체크인", location: { lat: 10.3648, lng: 103.8552 }, timeStartMin: 840, timeEndMin: 900 },
        { kind: "meal", name: "야시장 저녁", location: { lat: 10.216, lng: 103.959 }, timeStartMin: 1080, timeEndMin: 1200, costVnd: 250000 },
      ],
    },
    {
      label: "북부: 사파리 & 빈원더",
      items: [
        { kind: "spot", name: "Vinpearl Safari", location: { lat: 10.3669, lng: 103.8519 }, timeStartMin: 540, timeEndMin: 720, openMin: 540, closeMin: 1020, costVnd: 650000 },
        { kind: "spot", name: "VinWonders", location: { lat: 10.3661, lng: 103.8565 }, timeStartMin: 750, timeEndMin: 1020, openMin: 600, closeMin: 1260, costVnd: 950000 },
        { kind: "meal", name: "그랜드월드 저녁", location: { lat: 10.3648, lng: 103.8552 }, timeStartMin: 1110, timeEndMin: 1230, costVnd: 300000 },
      ],
    },
    {
      label: "남부: 케이블카 & 섬투어",
      items: [
        { kind: "spot", name: "An Thoi 케이블카", location: { lat: 9.994, lng: 104.006 }, timeStartMin: 540, timeEndMin: 690, costVnd: 550000 },
        { kind: "activity", name: "호남섬 스노클링", location: { lat: 9.955, lng: 104.030 }, timeStartMin: 720, timeEndMin: 990, costVnd: 700000 },
        { kind: "meal", name: "남부 해산물", location: { lat: 10.000, lng: 103.999 }, timeStartMin: 1050, timeEndMin: 1140, costVnd: 350000 },
      ],
    },
    {
      label: "자유 일정/출발",
      items: [
        { kind: "spot", name: "카페·수영", location: { lat: 10.298, lng: 103.964 }, timeStartMin: 600, timeEndMin: 720 },
        { kind: "activity", name: "공항 출발", location: { lat: 10.227, lng: 103.967 }, timeStartMin: 840, timeEndMin: 900 },
      ],
    },
  ],
};

export default tpl;
