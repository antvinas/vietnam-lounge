import type { PlanTemplate } from "@/types/plan.template";

const tpl: PlanTemplate = {
  meta: {
    id: "danang-3n4d",
    city: "Da Nang",
    title: "다낭 3박4일 샘플",
    nights: 3,
    defaultMode: "car",
    currency: "VND",
    plannedBudgetVnd: 7800000,
    summary: "미케비치·용다리·바나힐·호이안 반나절",
  },
  base: {
    name: "My Khe Beach 호텔",
    location: { lat: 16.067, lng: 108.246 },
  },
  days: [
    {
      label: "체크인/야경",
      items: [
        { kind: "spot", name: "미케 비치", location: { lat: 16.067, lng: 108.246 }, timeStartMin: 960, timeEndMin: 1050 },
        { kind: "spot", name: "용다리 야경", location: { lat: 16.061, lng: 108.227 }, timeStartMin: 1170, timeEndMin: 1260 },
      ],
    },
    {
      label: "바나힐",
      items: [
        { kind: "activity", name: "바나힐 입장/케이블카", location: { lat: 15.997, lng: 107.996 }, timeStartMin: 540, timeEndMin: 990, costVnd: 900000 },
      ],
    },
    {
      label: "호이안 반나절",
      items: [
        { kind: "spot", name: "호이안 구시가지", location: { lat: 15.880, lng: 108.338 }, timeStartMin: 780, timeEndMin: 1050 },
        { kind: "meal", name: "까오러우/반미", location: { lat: 15.877, lng: 108.33 }, timeStartMin: 1080, timeEndMin: 1140, costVnd: 120000 },
      ],
    },
    {
      label: "자유/출발",
      items: [
        { kind: "spot", name: "카페/스파", location: { lat: 16.067, lng: 108.246 }, timeStartMin: 600, timeEndMin: 720 },
        { kind: "activity", name: "공항 출발", location: { lat: 16.043, lng: 108.199 }, timeStartMin: 840, timeEndMin: 900 },
      ],
    },
  ],
};

export default tpl;
