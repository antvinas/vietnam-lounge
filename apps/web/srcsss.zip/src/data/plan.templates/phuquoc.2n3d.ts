import type { PlanTemplate } from "@/types/plan.template";

const tpl: PlanTemplate = {
  meta: {
    id: "phuquoc-2n3d",
    city: "Phu Quoc",
    title: "푸꾸옥 2박3일 샘플",
    nights: 2,
    defaultMode: "car",
    currency: "VND",
    plannedBudgetVnd: 6500000,
    summary: "사파리 또는 케이블카 중심 압축 코스",
  },
  base: {
    name: "Duong Dong 호텔",
    location: { lat: 10.222, lng: 103.959 },
  },
  days: [
    {
      label: "도착/체크인",
      items: [
        { kind: "activity", name: "공항 도착", location: { lat: 10.227, lng: 103.967 }, timeStartMin: 780, timeEndMin: 840 },
        { kind: "meal", name: "야시장 저녁", location: { lat: 10.216, lng: 103.959 }, timeStartMin: 1080, timeEndMin: 1170, costVnd: 250000 },
      ],
    },
    {
      label: "사파리/빈원더",
      items: [
        { kind: "spot", name: "Vinpearl Safari", location: { lat: 10.3669, lng: 103.8519 }, timeStartMin: 540, timeEndMin: 690, costVnd: 650000 },
        { kind: "spot", name: "VinWonders", location: { lat: 10.3661, lng: 103.8565 }, timeStartMin: 720, timeEndMin: 990, costVnd: 950000 },
      ],
    },
    {
      label: "자유/출발",
      items: [
        { kind: "spot", name: "카페·수영", location: { lat: 10.298, lng: 103.964 }, timeStartMin: 600, timeEndMin: 720 },
        { kind: "activity", name: "공항 출발", location: { lat: 10.227, lng: 103.967 }, timeStartMin: 840, timeEndMin: 900 },
      ],
    },
  ],
};

export default tpl;
