import type { PlanTemplate } from "@/types/plan.template";

const tpl: PlanTemplate = {
  meta: {
    id: "hanoi-2n3d",
    city: "Hanoi",
    title: "하노이 2박3일 샘플",
    nights: 2,
    defaultMode: "car",
    currency: "VND",
    plannedBudgetVnd: 5500000,
    summary: "호안끼엠·구시가지·문묘·쭈옹가 거리 위주",
  },
  base: {
    name: "Old Quarter 호텔",
    location: { lat: 21.035, lng: 105.85 },
  },
  days: [
    {
      label: "도착/구시가지",
      items: [
        { kind: "spot", name: "호안끼엠 호수", location: { lat: 21.0285, lng: 105.8542 }, timeStartMin: 960, timeEndMin: 1050 },
        { kind: "meal", name: "분짜 저녁", location: { lat: 21.033, lng: 105.852 }, timeStartMin: 1080, timeEndMin: 1140, costVnd: 150000 },
      ],
    },
    {
      label: "시티투어",
      items: [
        { kind: "spot", name: "문묘(국자감)", location: { lat: 21.028, lng: 105.835 }, timeStartMin: 540, timeEndMin: 630, openMin: 480, closeMin: 1020 },
        { kind: "spot", name: "호찌민 묘소 주변", location: { lat: 21.037, lng: 105.834 }, timeStartMin: 660, timeEndMin: 780 },
        { kind: "spot", name: "쭈옹가(Train Street)", location: { lat: 21.024, lng: 105.842 }, timeStartMin: 900, timeEndMin: 1020 },
      ],
    },
    {
      label: "자유/출발",
      items: [
        { kind: "spot", name: "성 요셉 성당", location: { lat: 21.0288, lng: 105.848 }, timeStartMin: 600, timeEndMin: 690 },
        { kind: "activity", name: "공항 출발", location: { lat: 21.217, lng: 105.804 }, timeStartMin: 840, timeEndMin: 900 },
      ],
    },
  ],
};

export default tpl;
